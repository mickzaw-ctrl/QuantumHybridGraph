"""Tests for the BGP/SDN routing-policy integration interface."""

import json

import networkx as nx

from quantum_hybrid_graph import (
    AdaptiveNRE,
    BGPSDNInterface,
    QuantumHybridGraph,
    RoutingPolicyCommand,
)


def _flood_kernel(seed: int = 7) -> QuantumHybridGraph:
    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=3, seed=seed)
    kernel.graph.add_edges_from([(i, i + 1) for i in range(8)])
    for i in range(9):
        kernel.graph.add_edge(99, i)
    return kernel


def test_routing_policy_command_renders_bgp_and_sdn():
    cmd = RoutingPolicyCommand(
        action="blackhole",
        target=10,
        protocol="bgp",
        reason="dos_flood_suspect",
        attributes={"withdraw": True},
    )
    bgp = cmd.to_bgp()
    sdn = cmd.to_sdn()
    assert "blackhole" in bgp
    assert "0.0.0.10/32" in bgp
    assert sdn["action"] == "DROP"
    assert sdn["protocol"] == "sdn"


def test_node_to_prefix_mapping():
    assert RoutingPolicyCommand._node_to_prefix(0) == "0.0.0.0/32"
    assert RoutingPolicyCommand._node_to_prefix(257) == "0.0.1.1/32"
    assert RoutingPolicyCommand._node_to_prefix("router-A") == "node:router-A"


def test_interface_quarantine_restore_path_commands():
    kernel = _flood_kernel()
    iface = BGPSDNInterface(kernel, protocol="bgp")

    q = iface.quarantine_to_policy(99, reason="flood")
    assert q.action == "blackhole"
    r = iface.restore_to_policy(99)
    assert r.action == "announce_route"
    p = iface.path_to_policy([1, 2, 3], reason="opt")
    assert p.action == "install_path"
    assert p.attributes["path"] == [1, 2, 3]
    w = iface.reweight_to_policy(5, local_pref=200)
    assert w.action == "set_local_pref"
    assert w.attributes["local_pref"] == 200

    # All commands journaled.
    assert len(iface.command_journal) == 4
    payload = iface.as_dict()
    assert payload["num_commands"] == 4
    assert len(payload["bgp"]) == 4
    assert len(payload["sdn"]) == 4


def test_commands_from_incidents_only_recommended():
    kernel = _flood_kernel()
    nre = AdaptiveNRE(kernel, critical_energy_threshold=0.85, adaptation_rate=0.4)
    nre.adapt_threshold()
    incidents = nre.detect_energy_anomalies(adapt=False)

    iface = BGPSDNInterface(kernel)
    recommended = iface.commands_from_incidents(incidents, only_recommended=True)
    all_cmds = BGPSDNInterface(kernel).commands_from_incidents(incidents, only_recommended=False)
    assert len(all_cmds) >= len(recommended)
    assert all(cmd.action == "blackhole" for cmd in all_cmds)


def test_adaptive_nre_quarantine_emits_routing_policy():
    kernel = _flood_kernel()
    nre = AdaptiveNRE(kernel, critical_energy_threshold=0.85, adaptation_rate=0.4)
    nre.adapt_threshold()
    events = nre.auto_quarantine(limit=1)

    assert events
    event = events[0]
    assert "routing_policy" in event
    assert "bgp" in event
    assert event["routing_policy"]["action"] == "blackhole"
    assert len(nre.routing.command_journal) == 1

    # Restore re-announces.
    restore = nre.restore_node(event["node"])
    assert restore["routing_policy"]["action"] == "announce_route"
    assert len(nre.routing.command_journal) == 2


def test_optimize_routes_via_qaoa_maps_clique_to_policy():
    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=3, seed=11)
    # A clear 4-clique should be selected as the optimal routing core.
    kernel.graph.add_edges_from((a, b) for i, a in enumerate(range(4)) for b in range(i + 1, 4))
    kernel.graph.add_edges_from([(3, 4), (4, 5)])

    result = kernel.optimize_routes_via_qaoa(backend="local", iterations=20)
    assert "clique" in result
    assert result["routing_policy"]["action"] == "install_path"
    assert "install path" in result["bgp"]
    assert result["sdn"]["action"] == "FORWARD"


def test_export_policy_bgp_and_sdn(tmp_path):
    kernel = _flood_kernel()
    iface = BGPSDNInterface(kernel)
    iface.quarantine_to_policy(99, reason="flood")
    iface.path_to_policy([1, 2], reason="opt")

    bgp_path = tmp_path / "policy.txt"
    iface.export_policy(str(bgp_path), fmt="bgp")
    text = bgp_path.read_text()
    assert "blackhole" in text
    assert "install path" in text

    sdn_path = tmp_path / "policy.json"
    iface.export_policy(str(sdn_path), fmt="sdn")
    data = json.loads(sdn_path.read_text())
    assert isinstance(data, list)
    assert len(data) == 2
    assert data[0]["protocol"] == "sdn"


def test_routing_interface_reuses_attached_nre_journal():
    kernel = _flood_kernel()
    nre = kernel.attach_reliability_engineer(critical_energy_threshold=0.85)
    nre.adapt_threshold()
    nre.auto_quarantine(limit=1)

    iface = kernel.routing_interface()
    # Same underlying journal as the NRE routing interface.
    assert iface is nre.routing
    assert len(iface.command_journal) >= 1
