from datetime import datetime, timezone

from social_trend_predictor import SocialPost, SocialTrendPredictor, generate_demo_posts


def test_social_post_extracts_terms_and_engagement():
    post = SocialPost(
        timestamp=datetime(2026, 1, 1, tzinfo=timezone.utc),
        platform="x",
        text="Testing #AI and #Quantum trend forecasting",
        likes=10,
        shares=2,
        comments=3,
        views=100,
    )
    terms = post.terms()
    assert "#ai" in terms
    assert "#quantum" in terms
    assert post.engagement == 10 + 2 * 3 + 3 * 2 + 0.01 * 100


def test_predictor_forecasts_demo_quantum_trend():
    predictor = SocialTrendPredictor(bucket_minutes=60)
    predictor.add_posts(generate_demo_posts(datetime(2026, 1, 1, 12, tzinfo=timezone.utc)))
    forecasts = predictor.forecast(min_mentions=2, top_n=5)
    terms = [item.term for item in forecasts]
    assert "#quantum" in terms
    quantum = next(item for item in forecasts if item.term == "#quantum")
    assert quantum.predicted_score >= quantum.current_score
    assert quantum.status in {"BREAKOUT", "EMERGING", "GROWING"}


def test_predictor_exports_reports(tmp_path):
    predictor = SocialTrendPredictor(bucket_minutes=60)
    predictor.add_posts(generate_demo_posts(datetime(2026, 1, 1, 12, tzinfo=timezone.utc)))
    json_path = tmp_path / "trend.json"
    md_path = tmp_path / "trend.md"
    predictor.export_json(str(json_path), min_mentions=2, top_n=5)
    predictor.export_markdown(str(md_path), min_mentions=2, top_n=5)
    assert json_path.exists()
    assert md_path.exists()
    assert "Social Trend Forecast Report" in md_path.read_text(encoding="utf-8")
