import networkx as nx

from quantum_hybrid_graph import (
    QuantumCliqueDetector,
    QuantumHybridGraph,
    QAOAOptimizer,
    QuantumPreferentialAttachment,
    compare_classical_vs_quantum,
)


def test_qpa_grows_graph():
    qpa = QuantumPreferentialAttachment(alpha=1.5, seed=1)
    for _ in range(15):
        qpa.add_node()
    assert qpa.graph.number_of_nodes() == 15
    assert qpa.graph.number_of_edges() == 14


def test_grover_detector_finds_known_clique():
    g = nx.complete_graph(4)
    g.add_edge(4, 5)
    detector = QuantumCliqueDetector(g, seed=1)
    clique = detector.grover_search_k_clique(4)
    assert clique is not None
    assert set(clique) == {0, 1, 2, 3}


def test_qaoa_extracts_valid_clique():
    g = nx.Graph()
    g.add_edges_from([
        (0, 1), (0, 2), (1, 2),
        (2, 3), (3, 4),
    ])
    opt = QAOAOptimizer(g, p_layers=1, seed=2)
    _, _, bs = opt.optimize(iterations=10)
    clique = opt.extract_clique(bs)
    for i, a in enumerate(clique):
        for b in clique[i + 1:]:
            assert g.has_edge(a, b)


def test_quantum_hybrid_graph_runs_cycles():
    kernel = QuantumHybridGraph(initial_nodes=6, clique_threshold=3, seed=3)
    for _ in range(5):
        kernel.run_cycle()
    summary = kernel.summary()
    assert summary["nodes"] == 11
    assert summary["edges"] >= 10
    assert "quantum_speedup_estimate" in summary


def test_benchmark_shape():
    result = compare_classical_vs_quantum(cycles=3, initial_nodes=5, seed=4)
    assert "classical" in result
    assert "quantum_simulated" in result
    assert result["classical"]["nodes"] == 8
    assert result["quantum_simulated"]["nodes"] == 8


def test_accelerator_detector_returns_ranked_details():
    import networkx as nx
    from quantum_hybrid_graph import GraphAcceleratorDetector

    g = nx.Graph()
    g.add_edges_from((a, b) for i, a in enumerate(range(5)) for b in range(i + 1, 5))
    g.add_edges_from([(4, 5), (5, 6), (6, 7)])

    detector = GraphAcceleratorDetector(g)
    accelerators = detector.detect(min_size=4, min_density=0.7)

    assert accelerators
    assert accelerators[0].kind == "clique"
    assert set(accelerators[0].nodes) == {0, 1, 2, 3, 4}
    assert accelerators[0].score > 0


def test_quantum_hybrid_graph_detect_accelerators_public_api():
    from quantum_hybrid_graph import QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=4, seed=9)
    kernel.graph.add_edges_from((a, b) for i, a in enumerate(range(4)) for b in range(i + 1, 4))
    kernel.graph.add_edge(3, 4)

    details = kernel.detect_accelerators(min_size=4)
    summary = kernel.summary()

    assert len(details) >= 1
    assert summary["num_accelerators"] >= 1
    assert summary["top_accelerators"][0]["size"] == 4


def test_network_connection_optimizer_connects_components():
    import networkx as nx
    from quantum_hybrid_graph import NetworkConnectionOptimizer

    g = nx.Graph()
    g.add_edges_from([(0, 1), (1, 2), (3, 4), (4, 5)])
    optimizer = NetworkConnectionOptimizer(g)

    selected = optimizer.optimize(add_edges=1)

    assert len(selected) == 1
    assert nx.is_connected(g)
    assert selected[0].component_gain == 1
    assert "connects components" in selected[0].reason


def test_quantum_hybrid_graph_optimize_connections_adds_shortcut():
    from quantum_hybrid_graph import QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=3, seed=11)
    kernel.graph.add_edges_from([(0, 1), (1, 2), (2, 3), (3, 4), (4, 5)])

    before_edges = kernel.graph.number_of_edges()
    proposals = kernel.propose_connection_optimizations(add_edges=2)
    selected = kernel.optimize_connections(add_edges=1)
    summary = kernel.summary()

    assert proposals
    assert selected
    assert kernel.graph.number_of_edges() == before_edges + 1
    assert summary["last_connection_candidates"]
    assert summary["connection_optimization_history"]


def test_graph_network_analyzer_report_contains_core_sections():
    import networkx as nx
    from quantum_hybrid_graph import GraphNetworkAnalyzer

    g = nx.Graph()
    g.add_edges_from([(0, 1), (1, 2), (2, 0), (2, 3), (3, 4)])
    report = GraphNetworkAnalyzer(g).analyze(top_n=3)
    data = report.as_dict()

    assert data["overview"]["nodes"] == 5
    assert data["connectivity"]["connected"] is True
    assert data["centrality"]["top_degree"]
    assert data["communities"]["num_communities"] >= 1
    assert data["recommendations"]


def test_quantum_hybrid_graph_analyze_network_and_export(tmp_path):
    from quantum_hybrid_graph import QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=6, clique_threshold=3, seed=12)
    kernel.graph.add_edge(0, 2)
    kernel.graph.add_edge(0, 3)
    kernel.graph.add_edge(2, 3)

    report = kernel.analyze_network(top_n=2)
    out = tmp_path / "analysis.json"
    saved = kernel.export_analysis_json(str(out), top_n=2)
    summary = kernel.summary()

    assert report.overview["nodes"] == 6
    assert out.exists()
    assert saved.endswith("analysis.json")
    assert summary["last_analysis"] is not None
    assert summary["analysis_history"]


def test_quantum_experiment_suite_runs_core_experiments():
    from quantum_hybrid_graph import QuantumExperimentSuite

    suite = QuantumExperimentSuite(seed=21)
    qpa = suite.experiment_qpa_growth(alphas=[1.0, 1.5], nodes=12)
    grover = suite.experiment_grover_clique_search(k_values=[3, 4])
    qaoa = suite.experiment_qaoa_max_clique(layers=[1], iterations=5)

    assert qpa.name == "qpa_growth_sweep"
    assert len(qpa.metrics["runs"]) == 2
    assert grover.metrics["runs"][0]["found"] is True
    assert qaoa.metrics["runs"][0]["valid_clique"] is True


def test_quantum_hybrid_graph_run_quantum_experiments_export(tmp_path):
    from quantum_hybrid_graph import QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=6, clique_threshold=3, seed=22)
    out = tmp_path / "experiments.json"
    result = kernel.run_quantum_experiments(include_full_suite=False, export_path=str(out))
    summary = kernel.summary()

    assert result["num_experiments"] == 2
    assert out.exists()
    assert summary["last_quantum_experiments"] is not None
    assert summary["quantum_experiment_history"]


def test_quantum_backend_registry_and_qubo_export(tmp_path):
    from quantum_hybrid_graph import QuantumBackendRegistry, QuantumHybridGraph

    registry = QuantumBackendRegistry()
    statuses = registry.statuses()
    assert "local_simulator" in statuses
    assert statuses["local_simulator"]["available"] is True

    kernel = QuantumHybridGraph(initial_nodes=4, seed=31)
    out = tmp_path / "qubo.json"
    saved = kernel.export_max_clique_qubo(str(out))
    result = kernel.solve_max_clique_with_backend("local", iterations=5)

    assert saved.endswith("qubo.json")
    assert out.exists()
    assert result["backend"] == "local_simulator"
    assert "clique" in result


def test_quantum_integration_guide_contains_templates():
    from quantum_hybrid_graph import QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=3, seed=32)
    guide = kernel.quantum_integration_guide()
    status = kernel.set_quantum_backend("qiskit")
    summary = kernel.summary()

    assert "qiskit" in guide["templates"]
    assert "pennylane" in guide["templates"]
    assert status.name == "qiskit"
    assert "quantum_backend_status" in summary


def test_qiskit_adapter_real_or_fallback_path():
    from quantum_hybrid_graph import QiskitAdapter

    g = nx.complete_graph(3)
    adapter = QiskitAdapter()
    result = adapter.solve_max_clique_qaoa(g, p_layers=1, iterations=2, seed=41)

    assert result["backend"] == "qiskit"
    assert result["mode"].startswith(("qiskit_statevector", "local_fallback"))
    assert "backend_status" in result
    assert "clique" in result
    for i, a in enumerate(result["clique"]):
        for b in result["clique"][i + 1:]:
            assert g.has_edge(a, b)


def test_pennylane_adapter_real_or_fallback_path():
    from quantum_hybrid_graph import PennyLaneAdapter

    g = nx.complete_graph(3)
    adapter = PennyLaneAdapter()
    result = adapter.solve_max_clique_qaoa(g, p_layers=1, iterations=2, seed=42)

    assert result["backend"] == "pennylane"
    assert result["mode"].startswith(("pennylane_default_qubit", "local_fallback"))
    assert "backend_status" in result
    assert "clique" in result
    for i, a in enumerate(result["clique"]):
        for b in result["clique"][i + 1:]:
            assert g.has_edge(a, b)


def test_dashboard_export(tmp_path):
    from quantum_hybrid_graph import QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=6, clique_threshold=3, seed=51)
    for _ in range(3):
        kernel.run_cycle()
    out = tmp_path / "dashboard.html"
    saved = kernel.export_dashboard_html(str(out))

    assert saved.endswith("dashboard.html")
    assert out.exists()
    content = out.read_text(encoding="utf-8")
    assert "QuantumHybridGraph Dashboard" in content
    assert "dashboard-data" in content
    assert "Accelerators" in content


def test_real_world_benchmark_suite_runs_small_dataset(tmp_path):
    from quantum_hybrid_graph import RealWorldBenchmarkSuite

    suite = RealWorldBenchmarkSuite(seed=61)
    datasets = {"karate_club": nx.karate_club_graph()}
    report = suite.run(datasets=datasets, top_n=3, add_edges=1, max_candidates=300)
    out_json = tmp_path / "benchmarks.json"
    out_md = tmp_path / "benchmarks.md"
    suite.export_json(str(out_json), datasets=datasets, top_n=3, add_edges=1, max_candidates=300)
    suite.export_markdown(str(out_md), datasets=datasets, top_n=3, add_edges=1, max_candidates=300)

    assert report["num_datasets"] == 1
    assert report["results"][0]["dataset"] == "karate_club"
    assert "global_efficiency_gain" in report["results"][0]["improvement"]
    assert out_json.exists()
    assert out_md.exists()


def test_adaptive_optimizer_loop_runs_and_records_result():
    from quantum_hybrid_graph import AdaptiveGraphOptimizer, QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=3, seed=71)
    kernel.graph.add_edges_from([(0, 1), (1, 2), (2, 3), (3, 4), (4, 5)])
    before_edges = kernel.graph.number_of_edges()

    optimizer = AdaptiveGraphOptimizer(kernel)
    result = optimizer.run(max_iterations=3, add_edges_per_step=1, max_candidates=100, patience=2)

    assert result.initial_objective <= result.best_objective + 1e-9
    assert result.accepted_steps + result.rejected_steps == len(result.steps)
    assert kernel.graph.number_of_edges() >= before_edges
    assert result.stopped_reason in {"max_iterations_reached", "patience_exhausted", "no_candidates", "complete_graph"}


def test_quantum_hybrid_graph_adaptive_optimize_api():
    from quantum_hybrid_graph import QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=3, seed=72)
    kernel.graph.add_edges_from([(0, 1), (1, 2), (3, 4), (4, 5)])
    result = kernel.adaptive_optimize(max_iterations=2, add_edges_per_step=1, max_candidates=100, patience=2)

    assert result.as_dict()["steps"]
    assert hasattr(kernel, "adaptive_optimization_result")
    assert hasattr(kernel, "adaptive_optimization_history")


def test_circuit_depth_selector_selects_p():
    from quantum_hybrid_graph import CircuitDepthSelector

    g = nx.complete_graph(4)
    selector = CircuitDepthSelector(g, backend="local", seed=81)
    result = selector.select(min_p=1, max_p=3, iterations=4, patience=2)

    assert 1 <= result.selected_p <= 3
    assert result.best_candidate.valid_clique is True
    assert result.candidates
    assert "Use p=" in result.recommendation


def test_quantum_hybrid_graph_select_circuit_depth_api():
    from quantum_hybrid_graph import QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=3, seed=82)
    kernel.graph.add_edges_from([(0, 1), (0, 2), (1, 2), (2, 3)])
    result = kernel.select_circuit_depth(min_p=1, max_p=2, iterations=3, patience=1)
    summary = kernel.summary()

    assert kernel.qaoa_layers == result.selected_p
    assert summary["circuit_depth_selection_result"] is not None
    assert summary["circuit_depth_selection_history"]


def test_qaoa_optimizer_accepts_external_optimizer_and_reports_purity():
    from quantum_hybrid_graph import QAOAOptimizer

    g = nx.complete_graph(3)
    opt = QAOAOptimizer(g, p_layers=1, seed=91)

    def external_optimizer(objective, x0, bounds, iterations):
        assert callable(objective)
        assert len(x0) == 2
        assert bounds
        objective(x0)
        return x0

    gamma, beta, bitstring = opt.optimize(iterations=2, optimizer_fn=external_optimizer)
    selected = opt.extract_selected_nodes(bitstring)
    purity = opt.clique_purity(selected)

    assert len(gamma) == 1
    assert len(beta) == 1
    assert 0.0 <= purity <= 1.0
    assert opt.clique_purity([0, 1, 2]) == 1.0


def test_optimize_via_qaoa_uses_clique_anchor_and_records_purity():
    from quantum_hybrid_graph import QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=3, seed=92)
    kernel.graph.add_edges_from([
        (0, 1), (0, 2), (1, 2),
        (3, 4), (4, 5),
        (2, 3),
    ])
    kernel.detect_accelerators(min_size=3)
    before_edges = kernel.graph.number_of_edges()
    added = kernel.optimize_via_qaoa(add_edges=1, max_candidates=100)
    summary = kernel.summary()

    assert "last_qaoa_result" in summary
    assert summary["last_qaoa_result"] is not None
    assert "projected_clique_purity" in summary["last_qaoa_result"]
    assert 0.0 <= summary["last_qaoa_result"]["projected_clique_purity"] <= 1.0
    assert kernel.graph.number_of_edges() >= before_edges
    assert isinstance(added, list)


def test_qaoa_optimizer_cobyla_metadata_and_purity():
    from quantum_hybrid_graph import QAOAOptimizer

    g = nx.complete_graph(4)
    opt = QAOAOptimizer(g, p_layers=1, seed=101)
    gamma, beta, bitstring = opt.optimize_cobyla(iterations=12, restarts=2)

    assert len(gamma) == 1
    assert len(beta) == 1
    assert isinstance(bitstring, str)
    assert opt.last_optimizer_metadata["optimizer"] == "multi_start_cobyla"
    assert "projected_clique_purity" in opt.last_optimizer_metadata
    assert 0.0 <= opt.last_optimizer_metadata["projected_clique_purity"] <= 1.0


def test_qaoa_default_optimize_uses_cobyla_metadata():
    from quantum_hybrid_graph import QAOAOptimizer

    g = nx.complete_graph(3)
    opt = QAOAOptimizer(g, p_layers=1, seed=102)
    opt.optimize(iterations=10)

    assert hasattr(opt, "last_optimizer_metadata")
    assert opt.last_optimizer_metadata["optimizer"] == "multi_start_cobyla"


def test_adaptive_nre_quarantine_and_sandbox_analysis():
    from quantum_hybrid_graph import AdaptiveNRE, QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=0, seed=111)
    kernel.graph.add_edges_from([(0, 1), (0, 2), (0, 3), (3, 4)])
    nre = AdaptiveNRE(kernel)

    event = nre.quarantine_node(0, reason="test_incident")
    analysis = nre.analyze_sandbox()

    assert event["status"] == "quarantined"
    assert 0 not in kernel.graph
    assert 0 in nre.quarantine_zone
    assert 0 in nre.sandbox
    assert analysis["sandbox_nodes"] >= 1
    assert analysis["quarantined_nodes"] == [0]


def test_network_reliability_report_detects_incidents():
    from quantum_hybrid_graph import AdaptiveNRE, QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=0, seed=112)
    kernel.graph.add_edges_from([(0, 1), (1, 2), (2, 3), (2, 4), (2, 5)])
    nre = AdaptiveNRE(kernel)
    report = nre.reliability_report()

    assert "health" in report
    assert "incidents" in report
    assert report["health"]["nodes"] == 6
    assert "critical_energy_threshold" in report
    assert nre.min_threshold <= report["critical_energy_threshold"] <= nre.max_threshold


def test_adaptive_nre_threshold_adapts_to_history():
    from quantum_hybrid_graph import AdaptiveNRE, QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=0, seed=7)
    # One hub with many low-degree leaves: most nodes have low normalized
    # energy, so the adaptive threshold should fall below the conservative
    # starting value as history accumulates.
    kernel.graph.add_edges_from([(0, i) for i in range(1, 16)])
    nre = AdaptiveNRE(kernel, critical_energy_threshold=0.9, adaptation_rate=0.5)

    start = nre.critical_energy_threshold
    for _ in range(5):
        info = nre.adapt_threshold()
    assert nre.energy_history
    assert nre.critical_energy_threshold < start
    assert nre.min_threshold <= nre.critical_energy_threshold <= nre.max_threshold
    assert info["samples"] >= 1


def test_adaptive_nre_detects_and_quarantines_dos_flood_node():
    from quantum_hybrid_graph import AdaptiveNRE, QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=0, seed=13)
    # Normal sparse chain plus one flooding/DoS hub connected to everyone.
    kernel.graph.add_edges_from([(i, i + 1) for i in range(10)])
    for i in range(11):
        kernel.graph.add_edge(99, i)

    nre = AdaptiveNRE(kernel, critical_energy_threshold=0.75, adaptation_rate=0.4)
    anomalies = nre.detect_energy_anomalies()

    assert anomalies
    top = anomalies[0]
    assert top.node == 99
    assert any("dos_flood_suspect" in reason for reason in top.reasons)

    events = nre.auto_quarantine(limit=1)
    assert events and events[0]["status"] == "quarantined"
    assert 99 not in kernel.graph
    assert 99 in nre.sandbox
    # Main network keeps operating after isolating the flood node.
    assert kernel.graph.number_of_nodes() >= 10


def test_find_clique_and_kcore_accelerators():
    import networkx as nx
    from quantum_hybrid_graph import GraphAcceleratorDetector

    g = nx.Graph()
    # Two disjoint 5-cliques.
    g.add_edges_from((a, b) for i, a in enumerate(range(5)) for b in range(i + 1, 5))
    g.add_edges_from((a, b) for i, a in enumerate(range(5, 10)) for b in range(i + 1, 10))

    detector = GraphAcceleratorDetector(g)
    cliques = detector.find_clique_accelerators(min_size=5)
    kcores = detector.find_k_core_accelerators(min_size=5)

    assert {0, 1, 2, 3, 4} in cliques
    assert {5, 6, 7, 8, 9} in cliques
    assert any(nodes >= {0, 1, 2, 3, 4} for nodes in kcores)


def test_intelligent_acceleration_adds_small_world_shortcut():
    from quantum_hybrid_graph import QuantumHybridGraph, AcceleratorDetectionReport

    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=4, seed=11)
    # Two 5-cliques joined by a single bridge edge -> long inter-cluster paths.
    kernel.graph.add_edges_from((a, b) for i, a in enumerate(range(5)) for b in range(i + 1, 5))
    kernel.graph.add_edges_from((a, b) for i, a in enumerate(range(5, 10)) for b in range(i + 1, 10))
    kernel.graph.add_edge(4, 5)

    before_edges = kernel.graph.number_of_edges()
    report = kernel.intelligent_acceleration(min_size=4, shortcut_edges=2, max_candidates=300)

    assert isinstance(report, AcceleratorDetectionReport)
    data = report.as_dict()
    assert data["accelerators"]
    assert kernel.graph.number_of_edges() >= before_edges
    # Shortcuts should not increase the average shortest path length.
    before_apl = data["before_metrics"]["average_shortest_path_length"]
    after_apl = data["after_metrics"]["average_shortest_path_length"]
    if before_apl is not None and after_apl is not None:
        assert after_apl <= before_apl
    assert kernel.summary()["last_intelligent_acceleration_report"] is not None


def test_adaptive_nre_export_incident_log(tmp_path):
    from quantum_hybrid_graph import AdaptiveNRE, QuantumHybridGraph
    import json

    kernel = QuantumHybridGraph(initial_nodes=0, seed=21)
    kernel.graph.add_edges_from([(i, i + 1) for i in range(8)])
    for i in range(9):
        kernel.graph.add_edge(99, i)

    nre = AdaptiveNRE(kernel, critical_energy_threshold=0.85, adaptation_rate=0.4)
    nre.auto_quarantine(limit=1)

    path = tmp_path / "nre_incident_log.json"
    nre.export_incident_log(str(path))
    log = json.loads(path.read_text())
    assert "adaptation" in log
    assert log["adaptation"]["critical_energy_threshold"] <= nre.max_threshold
    assert 99 in log["quarantine_zone"]
    assert log["sandbox"]["num_nodes"] >= 1

    # Append mode builds an audit trail. The first append absorbs the existing
    # single dict entry, the second adds one more -> 3 entries total.
    nre.export_incident_log(str(path), append=True)
    nre.export_incident_log(str(path), append=True)
    arr = json.loads(path.read_text())
    assert isinstance(arr, list) and len(arr) == 3


def test_dashboard_includes_security_panel_when_nre_attached(tmp_path):
    from quantum_hybrid_graph import AdaptiveNRE, QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=3, seed=21)
    kernel.graph.add_edges_from([(i, i + 1) for i in range(8)])
    for i in range(9):
        kernel.graph.add_edge(99, i)

    nre = AdaptiveNRE(kernel, critical_energy_threshold=0.85, adaptation_rate=0.4)
    nre.auto_quarantine(limit=1)

    out = kernel.export_dashboard_html(str(tmp_path / "dash.html"), nre=nre)
    html = (tmp_path / "dash.html").read_text()
    assert 'data-tab="security"' in html
    assert "renderSecurity" in html
    assert '"security"' in html


def test_dashboard_includes_routing_control_plane_panel(tmp_path):
    import json
    import re

    from quantum_hybrid_graph import AdaptiveNRE, QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=3, seed=21)
    kernel.graph.add_edges_from([(i, i + 1) for i in range(8)])
    for i in range(9):
        kernel.graph.add_edge(99, i)

    nre = AdaptiveNRE(kernel, critical_energy_threshold=0.85, adaptation_rate=0.4)
    nre.auto_quarantine(limit=1, adapt=False)
    # Emit one more command type so the journal is non-trivial.
    nre.routing.reweight_to_policy(0, local_pref=250, reason="prefer_core")

    out = kernel.export_dashboard_html(str(tmp_path / "dash.html"), nre=nre)
    html = (tmp_path / "dash.html").read_text()

    # UI hooks present.
    assert 'data-tab="routing"' in html
    assert "function renderRouting(" in html
    assert "setupRoutingProto()" in html
    assert 'class="proto-btn"' in html

    # Routing payload embedded with BGP + SDN renderings.
    match = re.search(
        r'<script id="dashboard-data" type="application/json">(.*?)</script>',
        html,
        re.S,
    )
    payload = json.loads(match.group(1))
    routing = payload["routing"]
    assert routing is not None
    assert routing["num_commands"] == len(routing["commands"]) >= 2
    assert len(routing["bgp"]) == routing["num_commands"]
    assert len(routing["sdn"]) == routing["num_commands"]
    actions = {c["action"] for c in routing["commands"]}
    assert "set_local_pref" in actions


def test_run_cycle_nre_monitoring_logs_incidents_each_cycle():
    from quantum_hybrid_graph import QuantumHybridGraph, AdaptiveNRE

    kernel = QuantumHybridGraph(initial_nodes=4, clique_threshold=3, seed=11)
    agent = kernel.enable_nre_monitoring(
        auto_quarantine=False,
        critical_energy_threshold=0.75,
        adaptation_rate=0.3,
    )

    assert isinstance(agent, AdaptiveNRE)
    assert kernel.nre is agent
    assert kernel.nre_monitoring_enabled

    for _ in range(5):
        kernel.run_cycle()

    # One incident snapshot recorded per cycle.
    assert len(kernel.nre_incident_history) == 5
    last = kernel.nre_incident_history[-1]
    assert last["cycle"] == kernel.cycle
    assert "critical_energy_threshold" in last
    assert "num_incidents" in last

    summary = kernel.summary()
    assert summary["nre_monitoring_enabled"] is True
    assert len(summary["nre_incident_history"]) == 5


def test_run_cycle_nre_auto_quarantine_and_json_log(tmp_path):
    import json
    from quantum_hybrid_graph import QuantumHybridGraph

    log_path = tmp_path / "cycle_incidents.json"
    kernel = QuantumHybridGraph(initial_nodes=5, clique_threshold=3, seed=7)
    kernel.enable_nre_monitoring(
        auto_quarantine=True,
        quarantine_limit=1,
        incident_log_path=str(log_path),
        critical_energy_threshold=0.8,
        adaptation_rate=0.4,
    )

    for _ in range(8):
        kernel.run_cycle()

    # Graph keeps evolving even though nodes may be quarantined mid-cycle.
    assert kernel.cycle == 8
    assert kernel.graph.number_of_nodes() > 0

    # JSON audit trail is appended every cycle.
    trail = json.loads(log_path.read_text())
    assert isinstance(trail, list)
    assert len(trail) == 8


def test_disable_nre_monitoring_keeps_agent_but_stops_logging():
    from quantum_hybrid_graph import QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=3, clique_threshold=3, seed=5)
    kernel.enable_nre_monitoring(critical_energy_threshold=0.75)
    kernel.run_cycle()
    assert len(kernel.nre_incident_history) == 1

    kernel.disable_nre_monitoring()
    assert kernel.nre is not None
    kernel.run_cycle()
    # No new snapshot recorded while disabled.
    assert len(kernel.nre_incident_history) == 1


def test_expand_qpa_robust_to_removed_nodes():
    from quantum_hybrid_graph import QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=0, seed=3)
    kernel.graph.add_edges_from([(0, 1), (1, 2), (2, 3)])
    kernel.graph.remove_node(1)  # create a gap in node numbering

    new_node = kernel.expand_qpa()
    assert new_node == 4  # max existing (3) + 1, not number_of_nodes()
    assert new_node in kernel.graph


def test_dashboard_security_panel_includes_monitoring_chart(tmp_path):
    from quantum_hybrid_graph import QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=6, clique_threshold=3, seed=7)
    nre = kernel.enable_nre_monitoring(
        auto_quarantine=True,
        quarantine_limit=1,
        critical_energy_threshold=0.8,
        adaptation_rate=0.4,
    )
    for _ in range(6):
        kernel.run_cycle()

    out = kernel.export_dashboard_html(str(tmp_path / "dash.html"), nre=nre)
    html = (tmp_path / "dash.html").read_text()

    # Chart markup + renderer present.
    assert 'id="securityChart"' in html
    assert "renderSecurityChart" in html
    # Per-cycle monitoring history embedded for the chart.
    assert "monitoring_history" in html

    import re
    import json

    m = re.search(
        r'<script id="dashboard-data" type="application/json">(.*?)</script>',
        html,
        re.S,
    )
    payload = json.loads(m.group(1))
    history = payload["security"]["monitoring_history"]
    assert len(history) == 6
    assert history[0]["cycle"] == 1
    assert all("critical_energy_threshold" in snap for snap in history)
    assert all("num_incidents" in snap for snap in history)


# ----------------------------------------------------------------------
# Recovery Procedures (self-healing back into production)
# ----------------------------------------------------------------------


def _build_nre_with_quarantine(node, neighbors, seed=7, threshold=0.9):
    from quantum_hybrid_graph import AdaptiveNRE, QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=3, seed=seed)
    kernel.graph.add_edges_from([(i, i + 1) for i in range(8)])
    for nb in neighbors:
        kernel.graph.add_edge(node, nb)
    nre = AdaptiveNRE(kernel, critical_energy_threshold=threshold, adaptation_rate=0.3)
    nre.quarantine_node(node, reason="test")
    return kernel, nre


def test_recover_node_returns_benign_node_and_reconnects_surviving_edges():
    kernel, nre = _build_nre_with_quarantine(99, [0, 1])

    assert 99 not in kernel.graph
    assessment = nre.assess_recovery(99)
    assert assessment["recoverable"] is True

    event = nre.recover_node(99)
    assert event["status"] == "recovered"
    assert event["edges_restored"] == 2
    assert 99 in kernel.graph
    assert set(kernel.graph.neighbors(99)) == {0, 1}
    # Sandbox is cleaned up and quarantine zone cleared.
    assert 99 not in nre.quarantine_zone
    assert nre.sandbox.number_of_nodes() == 0
    assert len(nre.recovery_history) == 1
    # A routing announce policy is emitted to the control plane.
    assert event["bgp"].startswith("announce")


def test_recover_node_defers_flood_hub_outlier():
    from quantum_hybrid_graph import AdaptiveNRE, QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=3, seed=21)
    kernel.graph.add_edges_from([(i, i + 1) for i in range(20)])
    for i in range(15):
        kernel.graph.add_edge(99, i)
    nre = AdaptiveNRE(kernel, critical_energy_threshold=0.85, adaptation_rate=0.4)
    nre.quarantine_node(99, reason="dos")

    assessment = nre.assess_recovery(99)
    assert assessment["recoverable"] is False
    assert assessment["degree_z_score"] >= 2.0

    result = nre.recover_node(99)
    assert result["status"] == "recovery_deferred"
    assert 99 not in kernel.graph  # still quarantined
    assert nre.auto_recover() == []


def test_rollback_quarantine_forces_restore():
    from quantum_hybrid_graph import AdaptiveNRE, QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=3, seed=21)
    kernel.graph.add_edges_from([(i, i + 1) for i in range(20)])
    for i in range(15):
        kernel.graph.add_edge(99, i)
    nre = AdaptiveNRE(kernel, critical_energy_threshold=0.85, adaptation_rate=0.4)
    nre.quarantine_node(99, reason="false_positive")

    # Even though assessment defers it, a forced rollback restores it.
    assert nre.assess_recovery(99)["recoverable"] is False
    event = nre.rollback_quarantine(99)
    assert event["status"] == "recovered"
    assert event["forced"] is True
    assert event["edges_restored"] == 15
    assert 99 in kernel.graph


def test_auto_recover_only_returns_ready_nodes_and_respects_limit():
    from quantum_hybrid_graph import AdaptiveNRE, QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=3, seed=5)
    kernel.graph.add_edges_from([(i, i + 1) for i in range(20)])
    # Two benign low-degree nodes + one flood hub.
    kernel.graph.add_edge(101, 0)
    kernel.graph.add_edge(102, 5)
    for i in range(15):
        kernel.graph.add_edge(199, i)

    nre = AdaptiveNRE(kernel, critical_energy_threshold=0.85, adaptation_rate=0.4)
    for node in (101, 102, 199):
        nre.quarantine_node(node, reason="test")

    recovered = nre.auto_recover()
    recovered_nodes = {e["node"] for e in recovered}
    assert recovered_nodes == {101, 102}
    assert 199 in nre.quarantine_zone  # flood hub stays deferred

    report = nre.recovery_report()
    assert set(report["deferred"]) == {199}
    assert report["num_recovered"] == 2


def test_recovery_data_surfaced_in_incident_log_and_dashboard_payload():
    kernel, nre = _build_nre_with_quarantine(99, [0, 1])
    nre.recover_node(99)

    log = nre.incident_log()
    assert log["num_recovered"] == 1
    assert log["recovery_history"][0]["node"] == 99

    payload = nre.security_dashboard_payload()
    assert payload["num_recovered"] == 1
    assert payload["recovery_history"][0]["status"] == "recovered"


# ----------------------------------------------------------------------
# Checkpoint / restore (full kernel state)
# ----------------------------------------------------------------------


def _edge_set(graph):
    return {tuple(sorted(e, key=str)) for e in graph.edges}


def test_checkpoint_restore_round_trip_structural_and_rng_fidelity():
    from quantum_hybrid_graph import QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=8, clique_threshold=4, seed=99)
    for _ in range(5):
        kernel.run_cycle()

    restored = QuantumHybridGraph.from_checkpoint(kernel.checkpoint())

    # Graph restored faithfully (nodes + edges + attrs).
    assert set(restored.graph.nodes) == set(kernel.graph.nodes)
    assert _edge_set(restored.graph) == _edge_set(kernel.graph)
    # Evolution clock + config restored.
    assert restored.cycle == kernel.cycle
    assert restored.clique_threshold == kernel.clique_threshold
    assert restored.qpa_alpha == kernel.qpa_alpha
    assert len(restored.history) == len(kernel.history)
    # RNG restored so the next deterministic draw is a continuation.
    assert restored.rng.bit_generator.state == kernel.rng.bit_generator.state
    assert kernel.expand_qpa() == restored.expand_qpa()


def test_checkpoint_save_and_from_checkpoint_file(tmp_path):
    from quantum_hybrid_graph import QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=6, clique_threshold=3, seed=7)
    for _ in range(4):
        kernel.run_cycle()

    path = tmp_path / "kernel_checkpoint.json"
    kernel.save_checkpoint(str(path))
    assert path.exists()

    restored = QuantumHybridGraph.from_checkpoint(str(path))
    assert set(restored.graph.nodes) == set(kernel.graph.nodes)
    assert _edge_set(restored.graph) == _edge_set(kernel.graph)
    assert restored.cycle == kernel.cycle


def test_checkpoint_restores_attached_nre_state():
    from quantum_hybrid_graph import QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=6, clique_threshold=3, seed=21)
    nre = kernel.enable_nre_monitoring(
        auto_quarantine=True,
        quarantine_limit=1,
        critical_energy_threshold=0.85,
        adaptation_rate=0.4,
    )
    for _ in range(8):
        kernel.run_cycle()
    # Force a recovery so recovery_history + routing journal are populated.
    nre.auto_recover()

    restored = QuantumHybridGraph.from_checkpoint(kernel.checkpoint())

    assert restored.nre is not None
    assert restored.nre_monitoring_enabled is True
    assert abs(restored.nre.critical_energy_threshold - nre.critical_energy_threshold) < 1e-9
    assert restored.nre.quarantine_zone == nre.quarantine_zone
    assert _edge_set(restored.nre.sandbox) == _edge_set(nre.sandbox)
    assert set(restored.nre.sandbox.nodes) == set(nre.sandbox.nodes)
    assert len(restored.nre.recovery_history) == len(nre.recovery_history)
    assert len(restored.nre.routing.command_journal) == len(nre.routing.command_journal)
    assert restored.nre_incident_history == kernel.nre_incident_history
    # The restored agent points at the restored kernel.
    assert restored.nre.kernel is restored


def test_checkpoint_without_nre_has_none_and_restores_clean():
    from quantum_hybrid_graph import QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=5, clique_threshold=3, seed=3)
    for _ in range(3):
        kernel.run_cycle()
    state = kernel.checkpoint()
    assert state["nre"] is None

    restored = QuantumHybridGraph.from_checkpoint(state)
    assert restored.nre is None
    assert restored.nre_monitoring_enabled is False


def test_restore_rejects_unknown_version():
    import pytest

    from quantum_hybrid_graph import QuantumHybridGraph

    kernel = QuantumHybridGraph(initial_nodes=4, clique_threshold=3, seed=1)
    state = kernel.checkpoint()
    state["version"] = 999
    with pytest.raises(ValueError):
        QuantumHybridGraph(initial_nodes=1).restore(state)
