#!/usr/bin/env python3
"""Example: export a standalone QuantumHybridGraph dashboard."""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantum_hybrid_graph import QuantumHybridGraph


kernel = QuantumHybridGraph(initial_nodes=10, clique_threshold=3, seed=42)
for _ in range(8):
    kernel.run_cycle()

path = kernel.export_dashboard_html("quantum_hybrid_graph_dashboard.html")
print(f"Dashboard saved to: {path}")
