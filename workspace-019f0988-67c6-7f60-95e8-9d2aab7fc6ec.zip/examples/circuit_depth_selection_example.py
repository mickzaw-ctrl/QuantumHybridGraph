#!/usr/bin/env python3
"""Example: select QAOA circuit depth p."""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantum_hybrid_graph import QuantumHybridGraph


kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=3, seed=42)
kernel.graph.add_edges_from([
    (0, 1), (0, 2), (0, 3),
    (1, 2), (1, 3), (2, 3),
    (3, 4), (4, 5),
])

result = kernel.select_circuit_depth(
    min_p=1,
    max_p=4,
    iterations=12,
    backend="local",
    patience=2,
)

print(result.as_dict())
print("Selected p:", kernel.qaoa_layers)
