#!/usr/bin/env python3
"""Example: forecast emerging social media trends."""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from social_trend_predictor import SocialTrendPredictor, generate_demo_posts


predictor = SocialTrendPredictor(bucket_minutes=60)
predictor.add_posts(generate_demo_posts())

forecasts = predictor.forecast(min_mentions=2, top_n=10)
for item in forecasts:
    print(item.as_dict())

predictor.export_markdown("social_trend_report.md", min_mentions=2, top_n=10)
print("Report saved to social_trend_report.md")
