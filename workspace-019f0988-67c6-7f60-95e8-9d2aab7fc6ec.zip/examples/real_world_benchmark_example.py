#!/usr/bin/env python3
"""Example: run real-world NetworkX dataset benchmarks."""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantum_hybrid_graph import RealWorldBenchmarkSuite


suite = RealWorldBenchmarkSuite(seed=42)
print("Available datasets:", list(suite.available_datasets()))

json_path = suite.export_json("real_world_benchmarks.json", top_n=5, add_edges=1, max_candidates=250)
md_path = suite.export_markdown("real_world_benchmarks.md", top_n=5, add_edges=1, max_candidates=250)

print(f"JSON benchmark report saved to: {json_path}")
print(f"Markdown benchmark report saved to: {md_path}")
