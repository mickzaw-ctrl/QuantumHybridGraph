#!/usr/bin/env python3
"""NRE security monitoring: dashboard panel + persistent incident logging.

This example:
  1. Builds a kernel and enables per-cycle NRE monitoring.
  2. Runs the evolution loop so the adaptive threshold, incidents and
     quarantine events accumulate a per-cycle history.
  3. Persists a JSON incident log (audit trail).
  4. Exports a standalone HTML dashboard whose Security panel charts the
     per-cycle monitoring history.
"""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantum_hybrid_graph import QuantumHybridGraph


def main() -> None:
    kernel = QuantumHybridGraph(initial_nodes=6, clique_threshold=3, seed=21)

    # Enable per-cycle monitoring: adapt threshold, log incidents and
    # auto-quarantine the top anomaly every cycle.
    nre = kernel.enable_nre_monitoring(
        auto_quarantine=True,
        quarantine_limit=1,
        incident_log_path="nre_incident_log.json",
        critical_energy_threshold=0.85,
        adaptation_rate=0.4,
    )

    for _ in range(12):
        kernel.run_cycle()

    print(f"Ran {kernel.cycle} cycles; threshold now {nre.critical_energy_threshold:.3f}")
    print(f"Quarantine zone: {sorted(nre.quarantine_zone)}")
    print(f"Monitoring history points: {len(kernel.nre_incident_history)}")
    print("Incident log (audit trail) written to: nre_incident_log.json")

    # Dashboard with embedded Security panel + per-cycle monitoring chart.
    dash_path = kernel.export_dashboard_html(
        "nre_security_dashboard.html",
        title="QuantumHybridGraph — NRE Security Dashboard",
        nre=nre,
    )
    print(f"Dashboard written to: {dash_path}")
    print("Open the dashboard and select the Security tab to see the chart.")


if __name__ == "__main__":
    main()
