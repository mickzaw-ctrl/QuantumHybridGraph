#!/usr/bin/env python3
"""Network Reliability Engineer (NRE) Agent demo.

Demonstrates the AdaptiveNRE agent responsible for network stability and
security:

  - Adaptation Logic: ``critical_energy_threshold`` is tuned online from
    historical network-energy data via ``adapt_threshold``.
  - Self-Healing:
      * Quarantine: ``quarantine_node`` / ``auto_quarantine`` isolate nodes
        showing DoS/flood-style anomalies.
      * Sandbox: quarantined nodes are moved into an isolated graph
        (``self.sandbox``) so threats can be analyzed without interrupting the
        main network.
"""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantum_hybrid_graph import AdaptiveNRE, QuantumHybridGraph


def build_network_with_flood_node() -> QuantumHybridGraph:
    """A normal sparse network plus a flooding/DoS hub node (id=99)."""
    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=3, seed=13)
    kernel.graph.add_edges_from([(i, i + 1) for i in range(12)])
    # Node 99 floods the network: it connects to almost every other node.
    for i in range(13):
        kernel.graph.add_edge(99, i)
    return kernel


def main() -> None:
    kernel = build_network_with_flood_node()
    nre = AdaptiveNRE(kernel, critical_energy_threshold=0.85, adaptation_rate=0.4)

    print("=== Adaptation Logic ===")
    print(f"initial critical_energy_threshold = {nre.critical_energy_threshold:.3f}")
    for step in range(3):
        info = nre.adapt_threshold()
        print(
            f"  step {step}: {info['previous_threshold']:.3f} -> "
            f"{info['new_threshold']:.3f} (target {info['target']:.3f})"
        )

    print("\n=== Anomaly detection (DoS/flood) ===")
    for incident in nre.detect_energy_anomalies()[:3]:
        print(f"  node={incident.node} risk={incident.risk_score:.3f} reasons={incident.reasons}")

    print("\n=== Self-Healing: auto-quarantine ===")
    events = nre.auto_quarantine(limit=2)
    for event in events:
        print(f"  {event['status']} node={event['node']} ({event['reason']})")

    print("\n=== Sandbox analysis ===")
    analysis = nre.analyze_sandbox()
    print(f"  sandbox nodes={analysis['sandbox_nodes']} edges={analysis['sandbox_edges']}")
    print(f"  quarantined={analysis['quarantined_nodes']}")
    print(f"  patterns={analysis['patterns']}")
    print(f"  adaptive threshold now = {analysis['critical_energy_threshold']:.3f}")

    print("\n=== Main network keeps operating ===")
    print(f"  main graph nodes={kernel.graph.number_of_nodes()} edges={kernel.graph.number_of_edges()}")
    print(f"  flood node 99 in main graph? {99 in kernel.graph}")


if __name__ == "__main__":
    main()
