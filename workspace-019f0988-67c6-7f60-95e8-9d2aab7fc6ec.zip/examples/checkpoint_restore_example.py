#!/usr/bin/env python3
"""Checkpoint / restore: full kernel state snapshot and disaster recovery.

The kernel state lives in memory. `checkpoint()` serializes everything needed to
rebuild it identically after a process restart:

  - the graph (nodes, edges, attributes),
  - the evolution clock and history,
  - the random generator state (deterministic continuation),
  - kernel configuration,
  - the attached AdaptiveNRE agent (threshold, sandbox, quarantine/recovery
    trails, BGP/SDN routing journal).

This example builds a kernel with NRE monitoring, takes a checkpoint, "loses"
the process, rebuilds from the JSON file and verifies the state is faithful.

Fidelity guarantees:
  * the restored graph has the same nodes, edges and attributes,
  * the RNG is restored, so the next deterministic operation is a continuation,
  * the NRE agent (sandbox, quarantine zone, audit trails) is reconstructed.
"""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantum_hybrid_graph import QuantumHybridGraph


def edge_set(graph):
    return {tuple(sorted(e, key=str)) for e in graph.edges}


def main() -> None:
    # 1. A live, evolving kernel with security monitoring.
    kernel = QuantumHybridGraph(initial_nodes=6, clique_threshold=3, seed=21)
    nre = kernel.enable_nre_monitoring(
        auto_quarantine=True,
        quarantine_limit=1,
        critical_energy_threshold=0.85,
        adaptation_rate=0.4,
    )
    for _ in range(8):
        kernel.run_cycle()
    nre.auto_recover()  # populate the recovery audit trail

    print("Before checkpoint:")
    print(f"  cycle={kernel.cycle} nodes={kernel.graph.number_of_nodes()} "
          f"edges={kernel.graph.number_of_edges()}")
    print(f"  quarantine_zone={sorted(nre.quarantine_zone, key=str)} "
          f"sandbox_nodes={nre.sandbox.number_of_nodes()} "
          f"recovered={len(nre.recovery_history)}")

    # 2. Persist the checkpoint to disk.
    path = kernel.save_checkpoint("kernel_checkpoint.json")
    print(f"\nCheckpoint written to: {path}")

    # 3. Simulate a restart: rebuild from the file only.
    restored = QuantumHybridGraph.from_checkpoint(path)

    print("\nAfter restore (from JSON file):")
    print(f"  cycle={restored.cycle} nodes={restored.graph.number_of_nodes()} "
          f"edges={restored.graph.number_of_edges()}")
    print(f"  nre attached={restored.nre is not None} "
          f"monitoring={restored.nre_monitoring_enabled}")
    print(f"  quarantine_zone={sorted(restored.nre.quarantine_zone, key=str)} "
          f"sandbox_nodes={restored.nre.sandbox.number_of_nodes()} "
          f"recovered={len(restored.nre.recovery_history)}")

    # 4. Verify fidelity.
    print("\nFidelity checks:")
    print(f"  same nodes        : {set(restored.graph.nodes) == set(kernel.graph.nodes)}")
    print(f"  same edges        : {edge_set(restored.graph) == edge_set(kernel.graph)}")
    print(f"  same cycle        : {restored.cycle == kernel.cycle}")
    print(f"  rng restored      : {restored.rng.bit_generator.state == kernel.rng.bit_generator.state}")
    print(f"  same threshold    : {abs(restored.nre.critical_energy_threshold - nre.critical_energy_threshold) < 1e-9}")
    print(f"  next op identical : {kernel.expand_qpa() == restored.expand_qpa()}")


if __name__ == "__main__":
    main()
