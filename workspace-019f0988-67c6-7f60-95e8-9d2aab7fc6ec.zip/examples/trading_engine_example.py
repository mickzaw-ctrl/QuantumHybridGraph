#!/usr/bin/env python3
"""Minimal asynchronous trading engine example.

This is a corrected, runnable version of the brokerage-style example.
It demonstrates:

- async order placement,
- basic validation,
- simple in-memory order book,
- deterministic order response structure.

It is intentionally educational and not production trading infrastructure.
"""

from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass
from enum import Enum
from typing import Any


class OrderSide(Enum):
    BUY = "BUY"
    SELL = "SELL"


@dataclass(frozen=True)
class Order:
    order_id: str
    symbol: str
    price: float
    volume: float
    side: OrderSide


class TradingEngine:
    """Simple asynchronous trading engine with an in-memory order book."""

    def __init__(self) -> None:
        self.order_book: list[Order] = []
        self._lock = asyncio.Lock()

    @staticmethod
    def validate_order(order: Order) -> None:
        """Validate basic order fields."""
        if not order.order_id:
            raise ValueError("Missing order_id")
        if not order.symbol:
            raise ValueError("Missing symbol")
        if order.price <= 0:
            raise ValueError("Invalid price")
        if order.volume <= 0:
            raise ValueError("Invalid volume")
        if not isinstance(order.side, OrderSide):
            raise ValueError("Invalid order side")

    async def place_order(self, order: Order) -> dict[str, Any]:
        """Asynchronously process and store an order."""
        self.validate_order(order)
        print(f"Processing {order.side.value} order for {order.symbol}...")

        # Lock protects the in-memory order book from concurrent writes.
        async with self._lock:
            self.order_book.append(order)

        # Simulate low-latency validation/matching work.
        await asyncio.sleep(0.001)

        return {
            "status": "FILLED",
            "order_id": order.order_id,
            "symbol": order.symbol,
            "side": order.side.value,
            "price": order.price,
            "volume": order.volume,
        }


async def main() -> None:
    """Example brokerage-style usage."""
    engine = TradingEngine()

    order = Order(
        order_id=str(uuid.uuid4()),
        symbol="WIG20",
        price=2450.50,
        volume=10.0,
        side=OrderSide.BUY,
    )

    result = await engine.place_order(order)
    print(f"Result: {result}")


if __name__ == "__main__":
    asyncio.run(main())
