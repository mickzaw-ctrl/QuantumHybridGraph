#!/usr/bin/env python3
"""Intelligent Acceleration module demo.

This example shows the two-stage Intelligent Acceleration pipeline:

  1. Accelerator detection
     - ``find_cliques``: fully connected, high-throughput clusters.
     - k-core decomposition: cohesive, resilient processing cores.

  2. Shortcut optimization (Small-World effect)
     - Long-range edges are proposed/added between clusters to reduce the
       latency of cross-cluster information transfer.
"""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantum_hybrid_graph import GraphAcceleratorDetector, QuantumHybridGraph


def build_two_cluster_graph() -> QuantumHybridGraph:
    """Two dense 5-cliques joined by a single bridge edge.

    The single bridge creates long inter-cluster paths, which the shortcut
    optimizer should shorten by adding a long-range link.
    """
    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=4, seed=11)
    kernel.graph.add_edges_from((a, b) for i, a in enumerate(range(5)) for b in range(i + 1, 5))
    kernel.graph.add_edges_from((a, b) for i, a in enumerate(range(5, 10)) for b in range(i + 1, 10))
    kernel.graph.add_edge(4, 5)
    return kernel


def main() -> None:
    kernel = build_two_cluster_graph()

    # --- Stage 1: raw detection algorithms ---------------------------------
    detector = GraphAcceleratorDetector(kernel.graph)
    print("Clique accelerators (find_cliques):")
    for clique in detector.find_clique_accelerators(min_size=5):
        print("  ", sorted(clique))
    print("K-core accelerators (k-core decomposition):")
    for core in detector.find_k_core_accelerators(min_size=5):
        print("  ", sorted(core))

    # --- Stage 2: detection + Small-World shortcut optimization -------------
    report = kernel.intelligent_acceleration(
        min_size=4,
        shortcut_edges=2,
        max_candidates=300,
        apply_shortcuts=True,
    )
    data = report.as_dict()

    print("\nRanked accelerators:")
    for acc in data["accelerators"][:5]:
        print(
            f"  kind={acc['kind']:<10} size={acc['size']} "
            f"density={acc['density']:.2f} score={acc['score']:.2f} nodes={acc['nodes']}"
        )

    print("\nAdded Small-World shortcuts:")
    for edge in data["added_shortcuts"]:
        print(f"  {edge['source']} <-> {edge['target']}  ({edge['reason']})")

    delta = data["small_world_delta"]
    print("\nSmall-World effect:")
    print(f"  global efficiency gain: {delta['global_efficiency_gain']:+.4f}")
    print(f"  average shortest-path reduction: {delta['average_shortest_path_reduction']}")


if __name__ == "__main__":
    main()
