#!/usr/bin/env python3
"""BGP/SDN integration: map graph operations to routing-policy updates.

This example shows the Integration & Protocols layer:

  - BGP/SDN Interface: the NRE maps graph operations (quarantine, restore) onto
    routing-policy update commands (blackhole / withdraw / announce).
  - Quantum Backend: the Qiskit/PennyLane (or local) MaxClique solver feeds the
    optimal cluster back into the control plane as a high-priority routing path.
"""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantum_hybrid_graph import AdaptiveNRE, QuantumHybridGraph


def build_network() -> QuantumHybridGraph:
    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=3, seed=7)
    # A normal sparse backbone ...
    kernel.graph.add_edges_from([(i, i + 1) for i in range(10)])
    # ... a dense, low-latency core (4-clique) ...
    kernel.graph.add_edges_from((a, b) for i, a in enumerate(range(2, 6)) for b in range(i + 1, 6))
    # ... and a flooding / DoS hub (id=99).
    for i in range(11):
        kernel.graph.add_edge(99, i)
    return kernel


def main() -> None:
    kernel = build_network()
    nre = kernel.attach_reliability_engineer(
        critical_energy_threshold=0.85,
        adaptation_rate=0.4,
    )

    print("=== BGP/SDN Interface: security-driven policy ===")
    nre.adapt_threshold()
    events = nre.auto_quarantine(limit=1, adapt=False)
    for event in events:
        print("BGP :", event["bgp"])
        print("SDN :", nre.routing.command_journal[-1].to_sdn())

    print("\n=== Quantum Backend MaxClique -> optimal routing path ===")
    result = kernel.optimize_routes_via_qaoa(backend="local", iterations=30)
    print("Optimal clique (routing core):", result["clique"])
    print("BGP :", result["bgp"])
    print("SDN :", result["sdn"])

    print("\n=== Restore a node (re-announce route) ===")
    restored = nre.restore_node(events[0]["node"]) if events else {}
    if restored.get("bgp"):
        print("BGP :", restored["bgp"])

    print("\n=== Export full routing policy ===")
    bgp_path = nre.routing.export_policy("routing_policy.txt", fmt="bgp")
    sdn_path = nre.routing.export_policy("routing_policy.json", fmt="sdn")
    print(f"BGP policy written to: {bgp_path}")
    print(f"SDN policy written to: {sdn_path}")
    print(f"Total journaled commands: {len(nre.routing.command_journal)}")


if __name__ == "__main__":
    main()
