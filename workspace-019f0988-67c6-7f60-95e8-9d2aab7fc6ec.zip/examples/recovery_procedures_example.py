#!/usr/bin/env python3
"""Recovery Procedures: evidence-based self-healing back into production.

The NRE quarantine layer isolates suspicious nodes into a sandbox. Recovery
Procedures are the controlled path that returns them to the live graph once the
conditions that triggered quarantine have cleared.

This example demonstrates:

  1. quarantining a benign low-degree node and a flood/DoS hub,
  2. `assess_recovery` — the evidence-based verdict (projected energy +
     degree z-score outlier test),
  3. `auto_recover` — recover only the nodes that are ready; flood hub stays
     deferred in the sandbox,
  4. `rollback_quarantine` — emergency forced restore of a false positive,
  5. `recovery_report` — the recovery audit trail.
"""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantum_hybrid_graph import AdaptiveNRE, QuantumHybridGraph


def main() -> None:
    kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=3, seed=5)
    kernel.graph.add_edges_from([(i, i + 1) for i in range(20)])
    # A benign low-degree node (transient blip) ...
    kernel.graph.add_edge(101, 0)
    # ... and a clear flood/DoS hub.
    for i in range(15):
        kernel.graph.add_edge(199, i)

    nre = AdaptiveNRE(kernel, critical_energy_threshold=0.85, adaptation_rate=0.4)

    print("== Quarantine ==")
    for node in (101, 199):
        nre.quarantine_node(node, reason="anomaly")
    print("Quarantine zone:", sorted(nre.quarantine_zone, key=str))

    print("\n== Recovery assessment ==")
    for node in (101, 199):
        a = nre.assess_recovery(node)
        verdict = "RECOVERABLE" if a["recoverable"] else "DEFER"
        print(f"  node {node}: {verdict}  (z={a['degree_z_score']}, {'; '.join(a['reasons'])})")

    print("\n== Auto recovery (only ready nodes) ==")
    events = nre.auto_recover()
    for e in events:
        print(f"  recovered node {e['node']} (+{e['edges_restored']} edges)  ->  {e['bgp']}")
    print("Still deferred in sandbox:", sorted(nre.quarantine_zone, key=str))

    print("\n== Emergency rollback (forced false-positive restore) ==")
    roll = nre.rollback_quarantine(199)
    print(f"  rollback node 199: status={roll['status']} forced={roll['forced']} "
          f"edges={roll['edges_restored']}")

    print("\n== Recovery report ==")
    report = nre.recovery_report()
    print("  recoverable_now:", report["recoverable_now"])
    print("  deferred       :", report["deferred"])
    print("  num_recovered  :", report["num_recovered"])


if __name__ == "__main__":
    main()
