#!/usr/bin/env python3
"""Automatic NRE security monitoring inside the run_cycle() evolution loop.

When NRE monitoring is enabled, every ``run_cycle`` call:
  1. grows the graph (QPA), detects accelerators and runs QAOA optimization,
  2. adapts the reliability ``critical_energy_threshold`` from history,
  3. (optionally) auto-quarantines anomalous DoS/flood nodes into the sandbox,
  4. records a per-cycle security incident snapshot,
  5. (optionally) appends the snapshot to a JSON audit trail.
"""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantum_hybrid_graph import QuantumHybridGraph


def main() -> None:
    kernel = QuantumHybridGraph(initial_nodes=6, clique_threshold=3, seed=7)

    # Enable monitoring: adapt + log every cycle, auto-quarantine top anomaly.
    kernel.enable_nre_monitoring(
        auto_quarantine=True,
        quarantine_limit=1,
        incident_log_path="cycle_incidents.json",
        critical_energy_threshold=0.8,
        adaptation_rate=0.4,
    )

    print("Running evolution with per-cycle NRE monitoring...\n")
    for _ in range(10):
        kernel.run_cycle()

    print(f"{'cycle':>5} | {'threshold':>9} | {'incidents':>9} | "
          f"{'quarantined_now':>15} | {'sandbox':>7}")
    print("-" * 60)
    for snap in kernel.nre_incident_history:
        print(
            f"{snap['cycle']:>5} | {snap['critical_energy_threshold']:>9.3f} | "
            f"{snap['num_incidents']:>9} | "
            f"{str(snap['quarantined_this_cycle']):>15} | {snap['sandbox_nodes']:>7}"
        )

    print(f"\nFinal graph: {kernel.graph.number_of_nodes()} nodes, "
          f"{kernel.graph.number_of_edges()} edges")
    print(f"Quarantine zone: {sorted(kernel.nre.quarantine_zone)}")
    print("JSON audit trail written to: cycle_incidents.json")


if __name__ == "__main__":
    main()
