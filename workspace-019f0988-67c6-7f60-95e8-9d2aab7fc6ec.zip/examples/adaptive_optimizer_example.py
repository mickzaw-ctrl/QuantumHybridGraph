#!/usr/bin/env python3
"""Example: run the adaptive optimizer loop."""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantum_hybrid_graph import QuantumHybridGraph


kernel = QuantumHybridGraph(initial_nodes=0, clique_threshold=3, seed=42)
kernel.graph.add_edges_from([
    (0, 1), (1, 2), (2, 3),
    (4, 5), (5, 6), (6, 7),
])

result = kernel.adaptive_optimize(
    max_iterations=5,
    add_edges_per_step=1,
    max_candidates=200,
    patience=3,
)

print(result.as_dict())
print("Final summary:")
print(kernel.summary())
