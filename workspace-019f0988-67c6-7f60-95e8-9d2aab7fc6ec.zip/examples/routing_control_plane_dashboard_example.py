#!/usr/bin/env python3
"""Routing / Control Plane dashboard panel demo.

This example shows the new **Routing** tab of the standalone dashboard, which
audits the BGP/SDN command journal produced by the NRE integration layer.

It deliberately exercises every command type so the panel demonstrates the
full control plane:

  1. Per-cycle NRE monitoring auto-quarantines anomalies -> ``blackhole``.
  2. ``optimize_routes_via_qaoa`` programs the densest clique as a high
     priority shortcut -> ``install_path``.
  3. A manual restore re-advertises a previously isolated node -> ``announce_route``.
  4. A manual re-weight steers traffic on a link -> ``set_local_pref``.

The dashboard's Routing tab lets you toggle between the BGP policy view and
the SDN / OpenFlow flow-rule view entirely offline (no network needed).
"""

from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantum_hybrid_graph import QuantumHybridGraph


def main() -> None:
    kernel = QuantumHybridGraph(initial_nodes=6, clique_threshold=3, seed=21)

    # 1. Per-cycle monitoring: adapt threshold, log incidents and
    #    auto-quarantine the top anomaly each cycle (emits blackhole policy).
    nre = kernel.enable_nre_monitoring(
        auto_quarantine=True,
        quarantine_limit=1,
        incident_log_path="nre_incident_log.json",
        critical_energy_threshold=0.85,
        adaptation_rate=0.4,
        routing_protocol="bgp",
    )

    for _ in range(10):
        kernel.run_cycle()

    # 2. Quantum backend -> install an optimized shortcut path (install_path).
    qaoa = kernel.optimize_routes_via_qaoa(iterations=40)
    print("QAOA clique programmed as shortcut path:", qaoa["clique"])

    # 3. Restore a quarantined node (announce_route).
    if nre.quarantine_zone:
        restored = sorted(nre.quarantine_zone)[0]
        nre.restore_node(restored)
        print(f"Restored node {restored} (announce_route)")

    # 4. Re-weight a live link to steer traffic (set_local_pref).
    live_nodes = [n for n in kernel.graph.nodes if n not in nre.quarantine_zone]
    if live_nodes:
        nre.routing.reweight_to_policy(
            live_nodes[0], local_pref=250, reason="prefer_low_latency_core"
        )
        print(f"Re-weighted node {live_nodes[0]} (set_local_pref)")

    journal = nre.routing.command_journal
    print(f"\nControl-plane command journal: {len(journal)} commands")
    for idx, cmd in enumerate(journal, start=1):
        print(f"  #{idx} {cmd.action} -> {cmd.target}")

    dash_path = kernel.export_dashboard_html(
        "nre_security_dashboard.html",
        title="QuantumHybridGraph — Security & Routing Dashboard",
        nre=nre,
    )
    print(f"\nDashboard written to: {dash_path}")
    print("Open the dashboard and select the Routing tab; toggle BGP / SDN view.")


if __name__ == "__main__":
    main()
