#!/usr/bin/env python3
"""Example: preparing QuantumHybridGraph for future Qiskit/PennyLane backends."""

from pathlib import Path
import sys

# Allow running this file directly from the examples/ directory without installing the package.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from quantum_hybrid_graph import QuantumHybridGraph


kernel = QuantumHybridGraph(initial_nodes=6, clique_threshold=3, seed=42)

print("Backend status:")
print(kernel.quantum_backend_status())

print("\nIntegration guide keys:")
guide = kernel.quantum_integration_guide()
print(guide["install"])

print("\nExporting backend-neutral QUBO:")
path = kernel.export_max_clique_qubo("max_clique_qubo.json")
print(path)

print("\nSolving through adapter interface:")
result = kernel.solve_max_clique_with_backend("local", iterations=10)
print(result)
