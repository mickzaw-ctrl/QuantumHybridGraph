# Recovery Procedures (Procedury Odzyskiwania)

Operational runbook for returning a NexusGraph Dynamics deployment — and
individual quarantined nodes — to a healthy production state after an incident.

This document is the operational companion to the reliability layer described
in the *Technical Reference Manual* §8/§8.1. It is written for **Network
Reliability Engineers (NRE)** and **Integrators** on call.

---

## 1. Scope and principles

Recovery is **evidence-based, not blind**. A node is returned to the production
graph only when the conditions that caused its quarantine are no longer present.
The two failure domains covered here are:

1. **Node-level** — a node was quarantined into the sandbox (DoS/flood,
   structural risk, or a false positive) and must be returned safely.
2. **System-level** — the whole kernel/process must be brought back up and its
   state reconstructed (restart, redeploy, disaster recovery).

Guiding principles:

- **Verify before restore.** Always run an assessment before reconnecting a node.
- **Least-privilege reconnection.** Only edges to *surviving* neighbours are
  restored; edges to nodes that were themselves removed are intentionally dropped.
- **Everything is audited.** Each restore is journaled (`recovery_history`) and
  pushed to the control plane as a routing policy (`announce_route`).
- **Forced overrides are explicit.** Emergency rollbacks of false positives are
  possible but recorded as `forced=True`.

---

## 2. Roles and ownership

| Step | Owner | Tooling |
|---|---|---|
| Detect & confirm incident | NRE | `reliability_report()`, dashboard Security panel |
| Assess recovery readiness | NRE | `assess_recovery(node)` |
| Execute node recovery | NRE | `recover_node()`, `auto_recover()` |
| Emergency rollback (false positive) | NRE lead | `rollback_quarantine(node)` |
| Control-plane propagation | Integrator | `nre.routing` (BGP/SDN announce), `export_policy()` |
| System restart / state rebuild | Integrator | checkpoint/replay (see §5) |
| Post-incident audit | NRE + Integrator | `recovery_report()`, JSON incident log |

---

## 3. Node-level recovery procedure

### 3.1 Quick reference

```python
from quantum_hybrid_graph import AdaptiveNRE

# 1. Inspect what is quarantined and whether it is ready to come back.
report = nre.recovery_report()
print(report["recoverable_now"], report["deferred"])

# 2. Assess a specific node (evidence: projected energy + degree z-score).
verdict = nre.assess_recovery(node_id)
print(verdict["recoverable"], verdict["reasons"])

# 3a. Recover everything that is ready (deferred nodes stay in the sandbox).
events = nre.auto_recover()

# 3b. Or recover one node explicitly.
nre.recover_node(node_id)                 # refuses if not recoverable
nre.recover_node(node_id, force=True)     # override (records forced=True)

# 4. Emergency rollback of a confirmed false positive.
nre.rollback_quarantine(node_id)

# 5. Propagate to the network and persist the audit trail.
nre.routing.export_policy("routing_policy.txt", fmt="bgp")
nre.export_incident_log("nre_incident_log.json", append=True)
```

### 3.2 Recovery assessment logic

`assess_recovery(node_id)` returns a verdict with the evidence used:

- **Projected energy** — the node's degree to *surviving* neighbours, normalized
  by the (post-recovery) maximum degree. Must sit within the safe band
  (`critical_energy_threshold` minus a small hysteresis margin) to avoid flapping.
- **Degree z-score outlier test** — a DoS/flood node remains a high-degree
  outlier (`z_score >= 2.0`) relative to the surviving degree distribution and is
  **deferred**. A benign node that is back within the pack is **recoverable**,
  even in sparse graphs where absolute energy is misleading after a hub removal.

A node is recoverable when it is *not* a degree outlier **or** its absolute
projected energy is within the safe band.

### 3.3 Step-by-step

1. **Confirm the incident has cleared.** Review the dashboard Security panel /
   `reliability_report()`. The threat traffic or structural fault should be gone.
2. **Assess.** Run `assess_recovery(node_id)`. If `recoverable` is `False`, leave
   the node in the sandbox and re-assess on the next cycle — do **not** force it
   unless §3.4 applies.
3. **Recover.** Call `recover_node(node_id)` (or `auto_recover()` for a batch).
   The node is re-attached, surviving edges are reconnected, the sandbox is
   cleaned, and an `announce_route` policy is emitted.
4. **Propagate.** The Integrator pushes the emitted routing policy to the BGP
   speaker / SDN controller (`nre.routing.export_policy(...)`).
5. **Audit.** Append to the JSON incident log and confirm `recovery_history`
   contains the event.

### 3.4 Emergency rollback (false positive)

If a quarantine decision is judged a false positive and the node must return
immediately regardless of the energy assessment:

```python
nre.rollback_quarantine(node_id)   # force restore + reconnect context
```

This is logged with `forced=True`. Use sparingly — a true DoS hub forced back in
will re-trigger detection on the next cycle.

---

## 4. Failure scenarios and responses

| Scenario | Symptom | Response |
|---|---|---|
| Transient blip quarantined | Low-degree node in sandbox, `recoverable=True` | `recover_node()` / `auto_recover()` |
| Confirmed DoS/flood hub | High `degree_z_score` outlier, `recoverable=False` | Keep deferred; remediate upstream; re-assess each cycle |
| False positive | Node quarantined but known-good | `rollback_quarantine()` |
| Many deferred nodes accumulating | `recovery_report()["deferred"]` growing | Investigate adaptation: is `critical_energy_threshold` stuck high? |
| Threshold instability | Threshold oscillating across cycles | Lower `adaptation_rate`; review per-cycle history in dashboard |

---

## 5. System-level recovery (restart & state rebuild)

The kernel state is held in memory. The supported way to recover a process is
**checkpoint & restore**: take periodic checkpoints during normal operation and
rebuild from the latest one after a restart.

### 5.1 Checkpoint & restore (preferred)

```python
# During normal operation: take periodic checkpoints.
kernel.save_checkpoint("kernel_checkpoint.json")

# After a restart / on a fresh process: rebuild from the latest checkpoint.
from quantum_hybrid_graph import QuantumHybridGraph
kernel = QuantumHybridGraph.from_checkpoint("kernel_checkpoint.json")
```

A checkpoint captures everything needed to reconstruct the deployment:

- the graph (nodes, edges and attributes),
- the evolution clock (`cycle`) and `history`,
- the random generator state,
- kernel configuration (`mode`, `qpa_alpha`, `qaoa_layers`, `clique_threshold`,
  `seed`),
- accelerator / analysis / connection / experiment histories,
- NRE monitoring flags and per-cycle incident history,
- the attached `AdaptiveNRE` agent — adaptive threshold, energy history, the
  **sandbox graph**, the **quarantine zone**, the quarantine/recovery audit
  trails and the BGP/SDN routing journal.

**Fidelity guarantees.** Restore reproduces the graph faithfully (same nodes,
edges, attributes), the evolution clock, the full NRE state and the RNG, so the
*next* deterministic operation is a continuation. Derived caches (rich report
objects, the backend registry) are recomputed lazily on demand. Note that
exact tie-breaking across many *future* cycles is not guaranteed to be
bit-identical after a re-serialized graph reload (per-node adjacency ordering is
not preserved by serialization); the recovered state itself is faithful.

After restore, re-export the routing policy and reconcile it against the live
BGP/SDN state so blackholes/announcements match the recovered graph:

```python
kernel.nre.routing.export_policy("routing_policy.txt", fmt="bgp")
```

See `examples/checkpoint_restore_example.py` for a runnable walkthrough.

### 5.2 Rebuild-and-replay (fallback, no checkpoint available)

If no checkpoint exists:

1. **Rebuild the graph** from the canonical source and re-create the kernel with
   the original `seed`.
2. **Re-attach the NRE** and seed `critical_energy_threshold` from the last
   persisted incident log so the agent does not re-learn from scratch:
   ```python
   nre = kernel.attach_reliability_engineer(
       critical_energy_threshold=last_known_threshold, adaptation_rate=...,
   )
   ```
3. **Replay the audit trail.** Load `nre_incident_log.json`; re-apply outstanding
   quarantine actions if the threats persist, then run the node-level recovery
   procedure (§3) for nodes whose conditions have cleared.
4. **Resume monitoring** with `enable_nre_monitoring(...)`.
5. **Reconcile the control plane** as in §5.1.

---

## 6. Verification checklist

After any recovery, confirm:

- [ ] `nre.quarantine_zone` no longer contains the recovered node(s).
- [ ] The node is present in `kernel.graph` with the expected surviving edges.
- [ ] `recovery_history` contains the recovery event(s).
- [ ] An `announce_route` policy was emitted and propagated to the control plane.
- [ ] The JSON incident log was appended (audit trail intact).
- [ ] `reliability_report()` shows the network within normal energy bounds.
- [ ] No immediate re-quarantine on the next `run_cycle()`.

See `examples/recovery_procedures_example.py` for a runnable walkthrough.
