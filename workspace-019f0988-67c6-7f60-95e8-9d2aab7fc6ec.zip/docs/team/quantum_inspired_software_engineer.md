# Quantum-Inspired Software Engineer

## Role summary

**Quantum-Inspired Software Engineer** is the specialist responsible for turning QuantumHybridGraph's quantum-inspired algorithms into reliable, testable and market-differentiating software.

This person specializes in quantum software libraries such as:

- Qiskit,
- PennyLane,
- qiskit-aer,
- qiskit-algorithms,
- quantum circuit simulation,
- QAOA-style optimization,
- QUBO / Ising model representations.

The role's primary mission is to make the product's **QAOA-style MaxClique optimization** a credible technical differentiator.

---

## Mission statement

> Build and maintain the quantum-inspired optimization layer that transforms graph problems into QUBO/Ising formulations, executes them through local and optional quantum SDK backends, validates the results, and exposes them through a stable product API.

---

## Why this role matters

QuantumHybridGraph is positioned between:

- graph intelligence,
- network optimization,
- AI infrastructure,
- quantum-ready optimization.

The market differentiator is not merely that the product analyzes graphs. The differentiator is that it offers a **quantum-inspired path for graph optimization**, especially around:

- MaxClique,
- accelerator detection,
- QAOA-style optimization,
- backend-neutral QUBO export,
- Qiskit/PennyLane readiness.

This role ensures that the quantum narrative is technically real, not just marketing language.

---

## Core responsibility

The Quantum-Inspired Software Engineer owns this question:

> Can this graph optimization problem be represented, simulated, validated and eventually executed through a quantum-compatible workflow?

This includes:

1. QUBO construction,
2. Ising Hamiltonian conversion,
3. QAOA circuit design,
4. backend adapter implementation,
5. simulator execution,
6. result decoding,
7. validation metrics,
8. benchmark comparison,
9. integration with graph optimization logic.

---

## Technical ownership areas

### 1. QAOA-style MaxClique

The engineer owns the implementation path for:

```python
QAOAOptimizer
QiskitAdapter.solve_max_clique_qaoa()
PennyLaneAdapter.solve_max_clique_qaoa()
QuantumHybridGraph.solve_max_clique_with_backend()
```

Responsibilities:

- represent MaxClique as QUBO,
- convert QUBO to Ising Z / ZZ terms,
- build QAOA ansatz circuits,
- optimize gamma/beta parameters,
- decode bitstrings into graph nodes,
- validate clique quality,
- expose consistent output schema.

---

### 2. Backend adapters

The engineer maintains backend parity across:

| Backend | Current role |
|---|---|
| `local_simulator` | Always available fallback |
| `qiskit` | Optional statevector execution path |
| `pennylane` | Optional `default.qubit` execution path |
| future cloud/hardware | Runtime or plugin integration |

All backend results must follow the same schema:

```python
{
    "backend": "qiskit",
    "mode": "qiskit_statevector",
    "bitstring": "10101",
    "clique": [...],
    "clique_size": 3,
    "energy": -3.0,
    "gamma": [...],
    "beta": [...],
    "backend_status": {...},
}
```

---

### 3. Quantum validation layer

The engineer ensures that quantum-inspired results are never accepted blindly.

Required validation metrics:

- QUBO energy,
- raw selected nodes,
- raw clique purity,
- projected clique,
- projected clique purity,
- valid clique flag,
- backend mode,
- optimizer metadata,
- circuit depth `p`,
- runtime.

Key implemented concepts:

```python
QAOAOptimizer.clique_purity(...)
QAOAOptimizer.extract_selected_nodes(...)
QAOAOptimizer.extract_clique(...)
QAOAOptimizer.last_optimizer_metadata
```

---

### 4. Circuit depth selection

The engineer owns the logic for choosing QAOA depth `p`:

```python
CircuitDepthSelector
QuantumHybridGraph.select_circuit_depth(...)
```

The goal is to avoid blindly using deeper circuits.

Depth selection must balance:

- clique quality,
- QUBO energy,
- runtime,
- backend mode,
- complexity penalty,
- stability.

---

### 5. Stable convergence

The engineer owns the stability of QAOA angle optimization.

Current implemented path:

```python
QAOAOptimizer.optimize_cobyla(...)
```

Responsibilities:

- maintain multi-start COBYLA,
- keep fallback optimizer dependency-light,
- record optimizer metadata,
- compare convergence across seeds,
- prevent unstable angle selection,
- prepare future optimizers such as SPSA or gradient-based methods.

---

## Product-level responsibility

This role turns quantum algorithms into product value.

The engineer should be able to explain:

- why QAOA-style MaxClique matters,
- how it helps detect dense graph structures,
- how dense structures become graph accelerators,
- how QAOA-derived cliques guide shortcut optimization,
- why this is useful for knowledge graphs, cybersecurity, AI agents and network optimization.

---

## Required design principles

### 1. Backend-neutral first

No product API should depend directly on Qiskit or PennyLane internals.

Correct pattern:

```python
kernel.solve_max_clique_with_backend("qiskit")
kernel.solve_max_clique_with_backend("pennylane")
kernel.solve_max_clique_with_backend("local")
```

Incorrect pattern:

```python
# Business logic directly importing Qiskit circuits everywhere
from qiskit import QuantumCircuit
```

Backend-specific imports should stay inside adapters.

---

### 2. Graceful fallback

The system must work even when optional quantum SDKs are not installed.

Required behavior:

- if Qiskit is missing → local fallback,
- if PennyLane is missing → local fallback,
- if graph is too large → local fallback or controlled error,
- if backend execution fails → structured fallback result.

---

### 3. Explainability over mystique

Quantum-inspired features must be explainable in practical terms.

Every result should answer:

- what problem was encoded?
- what backend was used?
- what bitstring was returned?
- what graph nodes were selected?
- is the selected group a valid clique?
- what is the clique purity?
- how does this affect graph optimization?

---

### 4. Small graphs first, scalable architecture later

Statevector simulation is exponential. The engineer must protect the product from unrealistic claims.

Current safe policy:

```text
n <= 20 for local statevector-style backend paths
```

For larger graphs:

- use subgraph selection,
- use accelerator anchors,
- use decomposition,
- use classical pre-filtering,
- use hybrid workflows.

---

## Key deliverables

### Current deliverables

- QUBO export for MaxClique.
- Local QAOA-like optimizer.
- Qiskit statevector execution path.
- PennyLane `default.qubit` execution path.
- Multi-start COBYLA optimizer.
- Clique purity validation.
- Circuit depth selection.
- QAOA-derived shortcut anchoring.

### Next deliverables

1. Qiskit Sampler / Runtime integration.
2. PennyLane plugin device configuration.
3. Backend parity benchmark report.
4. Optional CI job for `[quantum]` dependencies.
5. Notebook: MaxClique via local vs Qiskit vs PennyLane.
6. Hardware-ready QAOA interface.
7. Larger graph decomposition strategy.

---

## Technical backlog owned by this role

### Priority 1 — Backend maturity

- Add Qiskit Sampler path.
- Add Qiskit Runtime configuration hooks.
- Add PennyLane device selection parameter.
- Add backend configuration object.
- Normalize all backend result schemas.

### Priority 2 — QAOA quality

- Improve MaxClique QUBO penalty calibration.
- Compare COBYLA, SPSA and fallback optimizer.
- Add convergence traces.
- Add repeatability tests across seeds.
- Add automatic circuit depth selection benchmark.

### Priority 3 — Product integration

- Feed QAOA cliques directly into accelerator detection.
- Use QAOA clique purity in dashboard.
- Add QAOA optimizer traces to dashboard.
- Add quantum backend status to platform chatbot.
- Add investor-friendly quantum readiness report.

### Priority 4 — Scale strategy

- Subgraph extraction around accelerators.
- Community-wise QAOA.
- Sliding-window MaxClique.
- Hybrid decomposition.
- Sampling-based candidate reduction.

---

## Acceptance criteria

The quantum-inspired layer is healthy when:

1. QUBO export is deterministic.
2. Local, Qiskit and PennyLane paths return the same schema.
3. Missing SDKs do not break the product.
4. Every QAOA result includes clique purity.
5. Circuit depth `p` can be selected automatically.
6. COBYLA metadata is recorded.
7. QAOA-derived cliques influence graph optimization.
8. Backend limitations are documented honestly.
9. Tests cover local and fallback backend behavior.
10. The feature can be explained to non-quantum enterprise users.

---

## KPIs

### Engineering KPIs

- backend execution success rate,
- fallback rate,
- QAOA runtime per graph size,
- clique purity,
- QUBO energy improvement,
- convergence stability across seeds,
- circuit depth selected vs achieved score,
- test coverage for backend adapters.

### Product KPIs

- number of demos using QAOA differentiator,
- pilot customer interest in quantum-readiness,
- investor understanding of the quantum layer,
- dashboard usage of QAOA metrics,
- conversion from technical demo to pilot.

---

## Recommended profile

### Required skills

- Python,
- Qiskit or PennyLane,
- NumPy,
- graph algorithms,
- QUBO / Ising models,
- numerical optimization,
- testing and API design.

### Strong advantage

- QAOA,
- quantum circuit simulation,
- hybrid quantum-classical algorithms,
- optimization theory,
- NetworkX,
- SciPy / COBYLA / SPSA,
- cloud quantum runtimes.

---

## Role description for hiring / investor deck

**Quantum-Inspired Software Engineer**  
Software engineer specializing in Qiskit, PennyLane and hybrid quantum-classical optimization. Owns the QAOA-style MaxClique layer, backend adapters, QUBO/Ising conversion, circuit-depth selection and quantum result validation. Turns quantum-inspired graph optimization into a credible product differentiator for QuantumHybridGraph.

---

## Immediate implementation proposal

Add a backend configuration object:

```python
@dataclass
class QuantumBackendConfig:
    backend: str
    mode: str
    max_qubits: int
    shots: int | None
    optimizer: str
    p_layers: int
    seed: int | None
```

Then route all calls through:

```python
kernel.solve_max_clique_with_backend(config=config)
```

This would make Qiskit/PennyLane execution more production-ready and easier to expose through the dashboard and chatbot platform.
