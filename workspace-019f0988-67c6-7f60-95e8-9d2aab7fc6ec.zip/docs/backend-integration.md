# Qiskit and PennyLane backend integration

QuantumHybridGraph includes a backend adapter layer for running MaxClique/QAOA-style experiments through:

- the built-in local simulator,
- Qiskit statevector execution, when `qiskit` is installed,
- PennyLane `default.qubit` execution, when `pennylane` is installed.

If Qiskit or PennyLane are not installed, the adapters return a structured fallback result using the local simulator. This keeps the public API stable in all environments.

## Install optional quantum dependencies

```bash
pip install -e .[quantum]
```

Or install separately:

```bash
pip install qiskit qiskit-aer qiskit-algorithms
pip install pennylane
```

## Check backend status

```python
from quantum_hybrid_graph import QuantumHybridGraph

kernel = QuantumHybridGraph(initial_nodes=6, seed=42)
print(kernel.quantum_backend_status())
```

Example output without optional SDKs installed:

```python
{
    "local_simulator": {"available": True, "version": "builtin"},
    "qiskit": {"available": False, "reason": "qiskit is not installed"},
    "pennylane": {"available": False, "reason": "pennylane is not installed"},
}
```

## Solve MaxClique through a backend

```python
result = kernel.solve_max_clique_with_backend("local", iterations=30)
print(result)
```

With optional dependencies installed:

```python
qiskit_result = kernel.solve_max_clique_with_backend("qiskit", iterations=30)
pennylane_result = kernel.solve_max_clique_with_backend("pennylane", iterations=30)
```

Expected modes:

- `local_fallback` for the built-in simulator,
- `qiskit_statevector` for real Qiskit statevector execution,
- `pennylane_default_qubit` for real PennyLane `default.qubit` execution,
- `local_fallback_*` if an optional backend is unavailable or the graph is too large.

## Export QUBO

```python
kernel.export_max_clique_qubo("max_clique_qubo.json")
```

The exported problem is backend-neutral and can be converted to Qiskit or PennyLane objects.

## Current implementation details

### Qiskit

`QiskitAdapter.solve_max_clique_qaoa()` now:

1. Converts MaxClique QUBO to Ising Z / ZZ coefficients.
2. Builds a QAOA-style `QuantumCircuit`.
3. Applies cost layers with `RZ` and `RZZ` gates.
4. Applies mixer layers with `RX` gates.
5. Evaluates probabilities using `qiskit.quantum_info.Statevector`.
6. Runs a simple random-search optimizer over gamma/beta.
7. Decodes the best bitstring into a valid clique.

### PennyLane

`PennyLaneAdapter.solve_max_clique_qaoa()` now:

1. Converts MaxClique QUBO to Ising Z / ZZ coefficients.
2. Builds a `qml.qnode` on `default.qubit`.
3. Applies cost layers with `qml.RZ` and `qml.IsingZZ`.
4. Applies mixer layers with `qml.RX`.
5. Reads probabilities from `qml.probs`.
6. Runs a simple random-search optimizer over gamma/beta.
7. Decodes the best bitstring into a valid clique.

## Limitations

- Current Qiskit and PennyLane paths use local statevector simulators, not hardware.
- Graphs above 20 nodes fall back to the local simulator to avoid exponential memory usage.
- The optimizer is intentionally simple and dependency-light. A future version can add COBYLA/SPSA/gradient-based optimizers.

## Next steps

- Add Qiskit Runtime / Sampler support.
- Add PennyLane hardware/plugin device configuration.
- Add optional integration tests in CI for `[quantum]` dependencies.
- Add benchmark notebooks comparing local, Qiskit and PennyLane modes.
