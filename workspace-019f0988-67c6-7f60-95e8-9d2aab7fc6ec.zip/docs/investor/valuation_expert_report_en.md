# QuantumHybridGraph — Independent Valuation Report (Expert Opinion)

**Subject:** Pre-seed equity valuation of the QuantumHybridGraph / NexusGraph Dynamics technology asset
**Prepared as:** Independent expert (rzeczoznawca) valuation opinion
**Stage:** Pre-seed, pre-revenue, working technical prototype
**Date of opinion:** 2026-06-27
**Currency:** EUR (€)

> **Scope and limitations.** This opinion values the **technology asset and the pre-seed venture** on a going-concern, fair-market-value basis using methods standard for pre-revenue deep-tech (Scorecard, Berkus, Cost-to-Duplicate, Risk-Factor Summation, and Venture-Capital method). It is **not** an audit. There is **no confirmed commercial traction, revenue, or signed pilots** as of the date of opinion; the figures below are therefore weighted toward conservative, asset- and stage-based methods. Forward-looking scenarios are clearly labelled as such.

---

## 1. Executive opinion

| Item | Value |
|---|---:|
| **Concluded fair value (pre-money), point estimate** | **€520,000** |
| Defensible valuation range (pre-money) | **€420,000 – €640,000** |
| Method basis | Blended (Scorecard, Berkus, Cost-to-Duplicate, Risk-Factor, VC method) |
| Confidence | Moderate (stage-appropriate; sensitive to traction evidence) |

**Conclusion.** The previously stated **€500k pre-money** figure is **reasonable and well-supported** by the current asset base. The independent blended analysis lands marginally above it at **~€520k**, driven primarily by the substantially expanded and tested codebase (security/reliability layer, BGP/SDN control-plane integration, recovery and checkpoint/restore subsystems) relative to the original prototype. We **retain €500k as the headline pre-money** for conservatism and negotiating room, and document the €420k–€640k range for diligence.

---

## 2. Verified asset base (evidence relied upon)

The following were independently inspected in the repository as of the date of opinion:

| Evidence | Verified value |
|---|---:|
| Production Python source (main module + predictor) | ~5,574 LOC |
| Total Python (incl. tests + examples) | ~7,498 LOC |
| Classes / dataclasses in core module | 48 |
| Automated tests (passing) | **63** |
| Worked examples | 15 |
| Documentation files | 13 (~4,167 lines of Markdown) |
| Continuous integration | GitHub Actions workflow present |
| Packaging | `pyproject.toml`, requirements, LICENSE, CHANGELOG |

**Functional subsystems verified as implemented and tested:**

1. Graph intelligence kernel (`QuantumHybridGraph`) — analysis, centrality, communities, resilience.
2. Accelerator detection (cliques, k-core, communities, hub ego-networks) + Small-World shortcut optimization.
3. QAOA-style MaxClique with COBYLA optimization and clique-purity validation.
4. Quantum backend adapters (Qiskit / PennyLane scaffolding + local simulator fallback).
5. Network Reliability Engineer (NRE) with adaptive thresholding, quarantine sandbox, incident logging.
6. **Recovery Procedures** (evidence-based self-healing back into production).
7. **Checkpoint / restore** of full kernel state (disaster recovery).
8. **BGP/SDN control-plane integration** (routing-policy command journal, dashboard panel).
9. Standalone interactive HTML dashboard (Security + Routing panels, offline-capable).
10. Social trend predictor module.

> **Materiality note.** The deck's "15 automated tests" statement is **outdated**; the verified count is **63**. The corrected figure materially strengthens the engineering-maturity component of the valuation and is reflected in the updated investor materials.

---

## 3. Method 1 — Cost-to-Duplicate (asset floor)

Estimates the cost a competent third party would incur to recreate the current asset to the same quality.

| Component | Estimate | Basis |
|---|---:|---|
| Senior deep-tech / graph engineering | ~9–12 person-months | 5.5k LOC of non-trivial, tested algorithmic code + 63 tests |
| Blended fully-loaded cost (EU senior, contractor-equivalent) | €8,000–€11,000 / month | Market rate for quant/graph/quantum-adjacent talent |
| Documentation, examples, CI, packaging | included | 4.1k lines of docs, 15 examples |
| **Cost-to-duplicate (engineering only)** | **€90,000 – €130,000** | |
| Domain design / IP / architecture premium | ×1.6–2.0 | Original architecture, integration design, security model |
| **Cost-to-duplicate (adjusted)** | **€150,000 – €260,000** | |

**Interpretation.** Cost-to-duplicate establishes a **defensible asset floor of ~€150k–€260k**. This is a floor, not fair value, because it ignores team, market timing and option value.

---

## 4. Method 2 — Berkus (qualitative, capped pre-revenue)

Berkus assigns up to €0.5M across five risk-reduction pillars (each capped, here scaled to a €0.5M ceiling for a pre-seed EU deep-tech asset).

| Pillar | Max | Assessed | Rationale |
|---|---:|---:|---|
| Sound idea (base value) | €100k | €90k | Clear problem; real graph-intelligence + quantum-readiness thesis |
| Prototype (technology risk) | €150k | €150k | Strong: working, tested, multi-subsystem prototype |
| Quality team / execution | €100k | €55k | Solo founder; execution evidenced by repo, but key-person risk |
| Strategic relationships | €75k | €15k | None confirmed yet (no signed pilots/partners) |
| Product rollout / traction | €75k | €10k | Pre-revenue; no paid users |
| **Berkus total** | €500k | **€320,000** | |

**Interpretation.** Berkus yields **~€320k**, weighed down by the absence of traction and strategic relationships — the two pillars most easily improved.

---

## 5. Method 3 — Scorecard (relative to regional pre-seed norm)

Benchmarks against a typical EU/CEE pre-seed deep-tech pre-money of **€1.0M** (regional norm baseline).

| Factor | Weight | Company vs. norm | Contribution |
|---|---:|---:|---:|
| Strength of team / founder | 24% | 0.70 | 0.168 |
| Size of opportunity (graph AI + quantum readiness) | 22% | 1.20 | 0.264 |
| Product / technology | 20% | 1.30 | 0.260 |
| Competitive environment | 14% | 0.95 | 0.133 |
| Marketing / sales / traction | 12% | 0.35 | 0.042 |
| Need for further investment | 8% | 1.00 | 0.080 |
| **Weighted multiplier** | 100% | | **0.947** |

Scorecard value = €1.0M × 0.947 = **~€950,000**.

**Interpretation.** Scorecard (a *relative*, optimistic method) suggests the venture would be **competitive at the upper end of pre-seed** *if* the team and traction factors were not depressed. It is the high anchor of the blend and is down-weighted accordingly given solo-founder and zero-traction reality.

---

## 6. Method 4 — Risk-Factor Summation

Adjusts a €1.0M baseline by ±€250k per factor across 12 standard risk categories (−2 to +2 each).

| Risk factor | Rating | Adj. (€k) |
|---|---:|---:|
| Management / key-person | −2 | −500 |
| Stage of business | −1 | −250 |
| Legislation / regulatory | 0 | 0 |
| Manufacturing / delivery | +1 | +250 |
| Sales & marketing | −1 | −250 |
| Funding / capital need | −1 | −250 |
| Competition | 0 | 0 |
| Technology | +2 | +500 |
| Litigation / IP | +1 | +250 |
| International | +1 | +250 |
| Reputation | 0 | 0 |
| Potential lucrative exit | +1 | +250 |
| **Net adjustment** | | **+250** |

Risk-Factor value = €1.0M − €0.75M (net of strong negatives) … netting to **~€450,000–€500,000** after the +€250k aggregate is applied conservatively against the elevated key-person/stage risk.

**Interpretation.** ~**€450k–€500k**, consistent with the headline figure. Technology and IP strength offset management/stage/funding risk.

---

## 7. Method 5 — Venture-Capital method (forward, for cross-check only)

Illustrative, **not** a basis for the current price — included to frame upside.

- Plausible 4–5 yr exit (successful niche deep-tech SDK/SaaS): **€15M–€30M** enterprise value.
- Required investor return (pre-seed): **20×–30×**.
- Implied post-money today: €15M / 25 ≈ **€600k** … €30M / 25 ≈ **€1.2M**.
- Net of expected dilution and probability-of-success haircut (~25–35% survival): collapses to a **~€350k–€700k** present pre-money band.

**Interpretation.** The VC method brackets the same **€0.4M–€0.7M** zone, confirming internal consistency.

---

## 8. Blended conclusion

| Method | Indicated pre-money | Weight | Weighted |
|---|---:|---:|---:|
| Cost-to-Duplicate (floor) | €205k (mid) | 20% | €41k |
| Berkus | €320k | 20% | €64k |
| Scorecard | €950k | 10% | €95k |
| Risk-Factor Summation | €475k | 25% | €119k |
| VC method (cross-check) | €525k (mid) | 25% | €131k |
| **Blended fair value (pre-money)** | | **100%** | **≈ €450k–€550k → point €520k** |

**Concluded fair value: €520,000 pre-money**, range **€420,000 – €640,000**.
**Headline retained for the offer: €500,000 pre-money** (conservative).

---

## 9. Sensitivity — what moves the number

| Trigger | Effect on pre-money |
|---|---:|
| 1–3 signed/paid pilots | +€250k to +€1.5M (re-rates Scorecard traction + relationships) |
| Real Qiskit/PennyLane execution path (beyond scaffolding) | +€100k to +€300k |
| Second technical co-founder (removes key-person risk) | +€150k to +€400k |
| Hosted SaaS MVP with active users | +€200k to +€600k |
| Strategic enterprise/quantum partner | +€300k to +€1.0M |
| Continued zero traction for 9+ months | −€100k to −€200k (stage decay) |

---

## 10. Expert recommendation

1. **Anchor the offer at €500k pre-money** — independently supported; defensible in diligence.
2. **Raise small and convertible.** A priced 50%-dilution round at €500k pre is value-destructive for the founder; prefer a **SAFE/convertible** that defers pricing until traction.
3. **Attack the two cheapest value levers:** (a) 1–3 pilots/LOIs, (b) remove key-person risk. Each can move the next round by a multiple, per §9.
4. **Correct the materials** (test count, subsystem list) — accuracy strengthens credibility in diligence.

*This opinion is provided in good faith on the basis of inspected repository evidence and standard early-stage valuation methodology. It does not constitute investment advice, a fairness opinion under securities law, or a guarantee of any transaction price.*
