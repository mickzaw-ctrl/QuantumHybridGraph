# QuantumHybridGraph — Current Valuation Memo

> **Independent backing.** This memo is supported by an independent expert
> valuation opinion ([`valuation_expert_report_en.md`](valuation_expert_report_en.md))
> that blends five standard pre-revenue methods (Cost-to-Duplicate, Berkus,
> Scorecard, Risk-Factor Summation and the VC method). The expert's concluded
> fair value is **€520k pre-money** within a defensible range of **€420k–€640k**.
> We retain **€500k** as the conservative headline figure for the offer.

## Current value

**Current pre-seed valuation: €500k pre-money** (independent fair-value range €420k–€640k)

This valuation reflects the present stage of the project — a working, multi-subsystem technical prototype that has grown materially beyond the original engine:

- working technical prototype, GitHub-ready repository,
- **63 automated tests passing**, GitHub Actions CI,
- ~5,600 lines of tested core Python across 48 classes/dataclasses,
- graph analysis, accelerator detection and connection-optimization engine,
- Network Reliability Engineer (NRE): adaptive thresholding, quarantine sandbox, incident logging,
- **Recovery Procedures** (evidence-based self-healing) and **checkpoint/restore** (disaster recovery),
- **BGP/SDN control-plane integration** with a routing-policy command journal,
- standalone interactive dashboard (Security + Routing panels),
- Qiskit/PennyLane adapter scaffolding,
- investor pitch deck and ~4,200 lines of technical documentation,
- no confirmed commercial traction (pilots/revenue) yet.

Because the project is still before paid pilots or revenue, €500k is a conservative current valuation; the asset floor alone (cost-to-duplicate) is independently assessed at €150k–€260k.

---

## Recommended fundraising approach

At a €500k current valuation, raising the full €500k immediately would be highly dilutive.

### Recommended first close

| Parameter | Value |
|---|---:|
| Round | Pre-seed / angel |
| Current pre-money valuation | **€500k** |
| Recommended raise | **€150k–€250k** |
| Post-money at €250k raise | **€750k** |
| Investor ownership at €250k raise | **~33.3%** |
| Target runway | **6–9 months** |

This is a more balanced structure for an early prototype.

---

## If raising €500k now

| Parameter | Value |
|---|---:|
| Raise | **€500k** |
| Pre-money valuation | **€500k** |
| Post-money valuation | **€1.0M** |
| Investor ownership | **50%** |

This is mathematically valid, but not founder-friendly. It should only be accepted if the investor brings exceptional strategic value, such as enterprise access, technical team support or deeptech follow-on funding.

---

## Preferred alternative: SAFE / convertible note

A convertible structure may be better at this stage.

| Parameter | Value |
|---|---:|
| Instrument | SAFE / convertible note |
| Initial raise | **€150k–€250k** |
| Valuation cap | **€500k–€750k** |
| Discount | **20%** |

This allows the project to reach validation milestones before pricing a larger round.

---

## Use of funds for a €250k first close

| Area | Share | Amount |
|---|---:|---:|
| Engineering / SDK / backend | 40% | €100k |
| Product dashboard / UX | 15% | €37.5k |
| Enterprise pilots / customer work | 20% | €50k |
| Qiskit/PennyLane integration + R&D | 10% | €25k |
| GTM / content / community | 10% | €25k |
| Legal / cloud / operations | 5% | €12.5k |

---

## Milestones before a higher valuation round

Target milestones for the first 6–9 months (these are the cheapest value levers — see the expert report §9 sensitivity table):

1. Public repository and documentation. *(done)*
2. v0.2 SDK release.
3. Hosted demo / dashboard MVP.
4. First real-world benchmark datasets.
5. **1–3 enterprise pilot conversations or paid pilots** *(highest-leverage: re-rates traction + relationships)*.
6. Real Qiskit/PennyLane execution path beyond adapter scaffolding.
7. First case study or pilot report.
8. **Second technical co-founder** to remove key-person risk (largest single negative in the risk-factor analysis).

---

## Upside scenario after validation

If the project secures paid pilots, early revenue or a strong strategic partner, the next round can be priced higher.

| Parameter | Value |
|---|---:|
| Next raise | **€500k–€1.0M** |
| Pre-money valuation | **€2.5M–€5.0M** |
| Requirement | Paid pilots / early revenue / case studies |

---

## Suggested investor wording

> QuantumHybridGraph is currently valued at **€500k pre-money**. We are looking for an initial **€150k–€250k pre-seed/angel round** or a SAFE with a **€500k–€750k cap** to validate enterprise pilots and prepare the product for a larger seed round.

If the investor insists on a larger commitment:

> A full **€500k raise** is possible at the current **€500k pre-money valuation**, resulting in a **€1.0M post-money valuation** and **50% investor ownership**. We would prefer this only with a strategic investor who can significantly accelerate customer access and follow-on financing.

---

## Summary

Current value:

**€500k pre-money**

Recommended first raise:

**€150k–€250k**

Preferred structure:

**SAFE / convertible note with €500k–€750k cap and 20% discount**

Avoid unless highly strategic:

**€500k raise at €500k pre-money**, because it implies **50% dilution**.
