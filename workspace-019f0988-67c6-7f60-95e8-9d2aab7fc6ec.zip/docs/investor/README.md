# Investor Materials

This directory contains English investor-facing materials for QuantumHybridGraph.

## Files

- `investor_pitch_deck_en.html` — presentation-style HTML pitch deck.
- `investor_pitch_deck_en.md` — editable Markdown version of the pitch deck.
- `valuation_memo_en.md` — current valuation and fundraising memo.
- `valuation_expert_report_en.md` — **independent expert valuation opinion**
  (five-method blend, diligence-grade) backing the headline figure.

## Current valuation assumption

- Current valuation: **€500k pre-money** (independent fair-value range **€420k–€640k**, point estimate €520k)
- Asset floor (cost-to-duplicate): **€150k–€260k**
- Recommended first raise: **€150k–€250k**
- Preferred structure: **SAFE / convertible note with €500k–€750k cap and 20% discount**

## Verified project status (as of 2026-06-27)

- **63 automated tests passing**, GitHub Actions CI
- ~5,600 LOC tested core Python, 48 classes/dataclasses, 15 worked examples
- Subsystems: graph intelligence, accelerator detection, QAOA/COBYLA MaxClique,
  Qiskit/PennyLane adapters, NRE security layer, Recovery Procedures,
  checkpoint/restore, BGP/SDN control-plane integration, interactive dashboard
