# NexusGraph Dynamics: Technical Reference Manual

## How to use this manual

This manual serves three audiences. Start with the section that matches your
role, then branch out as needed.

| Role | Read first | Your responsibility |
|---|---|---|
| **Algorithm engineers** | §2 *Hamiltonian of the Network* (and §1 *Core Kernel* for context) | Own the cost/utility model. **Every change to the Hamiltonian must be backed by a unit test in `tests/test_quantum_hybrid_graph.py`.** |
| **Network reliability engineers (NRE)** | §8 / §8.1 *Reliability and Quarantine Layer* | Monitor the security layer. Your goal is to confirm that `critical_energy_threshold` **stabilizes over time under normal load** (no runaway drift, no oscillation). |
| **Integrators** | §12b *Integration & Protocols* | Own the touch points with the customer's real infrastructure. This is where the BGP/SDN control-plane contract is defined. |

### Role notes

- **Algorithm engineers — §2.** The Hamiltonian $H[G]$ and its utility mapping
  $U[G] = -H[G] + \alpha\,\text{efficiency} + \beta\,\text{clustering}$ are the
  ground truth for "is this graph state better?". Treat them as a public API:
  any modification (new term, re-weighting, sign change) requires a corresponding
  unit test so regressions are caught by `python3 -m pytest -q`.
- **Network reliability engineers — §8.1.** The Adaptation Logic moves
  `critical_energy_threshold` toward the historical high-energy band, clamped to
  `[min_threshold, max_threshold]`. Under steady, normal load the threshold
  should converge and stay roughly flat; use the per-cycle monitoring history
  (`kernel.nre_incident_history`, charted in the dashboard **Security** panel) to
  verify stabilization and to spot drift caused by load anomalies. For returning
  quarantined nodes to production, follow the **Recovery Procedures** runbook
  (`docs/recovery_procedures.md`) and the recovery API in §8.1.
- **Integrators — §12b.** `BGPSDNInterface` is the seam between graph decisions
  and the customer's network. Graph operations become protocol-neutral
  `RoutingPolicyCommand`s rendered as BGP statements (`to_bgp`) or SDN/OpenFlow
  flow rules (`to_sdn`), journaled for audit/replay. The dashboard **Routing /
  Control Plane** panel exposes that journal for review before it reaches
  production gear.

> **Numbering note.** Earlier conceptual drafts referred to these topics as
> sections 1–4 (Hamiltonian, NRE threshold, integration points). In this
> manual the implemented numbering is **§2** (Hamiltonian), **§8/§8.1** (NRE and
> `critical_energy_threshold`) and **§12b** (integration with real
> infrastructure). The section titles in the table above are authoritative.

---

## 1. System Architecture — Core Kernel

NexusGraph Dynamics is built on top of the `QuantumHybridGraph` library. The central execution layer is the kernel abstraction, represented in the current codebase by:

```python
UniverseKernel
QuantumHybridGraph
```

In conceptual documentation this may be referred to as `Universe_Kernel`, but the implementation name is currently:

```python
UniverseKernel
```

The kernel manages the graph lifecycle:

1. graph initialization,
2. graph expansion,
3. accelerator detection,
4. QAOA-style optimization,
5. connection optimization,
6. adaptive iteration,
7. dashboard/report export.

---

## 1.1 Graph Engine

The graph engine uses `networkx` as the primary data structure.

```python
import networkx as nx
```

The graph is stored as:

```python
kernel.graph: nx.Graph
```

### Interpretation

| Graph element | NexusGraph meaning |
|---|---|
| Node | Information unit, agent, concept, infrastructure element, risk object or market signal |
| Edge | Cost-bearing relationship, dependency, communication path or influence channel |
| Edge weight / latency | Operational cost, delay, risk, friction or energetic resistance |
| Clique | Dense coordination structure / accelerator |
| Community | Modular subsystem |
| Bridge | Fragile dependency between subsystems |
| Hub | High-load routing point |
| Sandbox | Quarantine environment for risky or infected nodes |

---

## 1.2 Kernel Classes

### `UniverseKernel`

Base graph lifecycle class.

Responsibilities:

- initialize graph,
- add nodes,
- record history,
- produce base summary.

Core methods:

```python
expand()
run_cycle()
summary()
```

---

### `QuantumHybridGraph`

Main hybrid graph intelligence kernel.

Extends `UniverseKernel` with:

- QPA-like graph growth,
- accelerator detection,
- QAOA-style clique search,
- adaptive connection optimization,
- graph analysis,
- real-world benchmarks,
- Qiskit/PennyLane backend adapters,
- dashboard export.

Core methods:

```python
run_cycle()
detect_accelerators()
optimize_via_qaoa()
optimize_connections()
analyze_network()
adaptive_optimize()
select_circuit_depth()
export_dashboard_html()
solve_max_clique_with_backend()
checkpoint()
save_checkpoint()
restore()
from_checkpoint()
```

---

# 2. Hamiltonian of the Network

The Hamiltonian is the energy-like function that evaluates the current state of the network.

Conceptually:

$$
H[G] = \sum_{v \in V} \text{load}(v) + \lambda \cdot \sum_{(i,j) \in E} \text{latency}(i,j)
$$

Where:

- $G = (V, E)$ is the graph,
- $V$ is the set of nodes,
- $E$ is the set of edges,
- $\text{load}(v)$ is the computational/informational load of node $v$,
- $\text{latency}(i,j)$ is the cost or delay of edge $(i,j)$,
- $\lambda$ is the edge-cost scaling factor.

The system attempts to minimize $H[G]$ while preserving or increasing useful connectivity.

---

## 2.1 Practical Hamiltonian Implementation

A practical implementation can be expressed as:

```python
def graph_hamiltonian(graph, lambda_latency=1.0):
    node_load = sum(graph.nodes[n].get("load", graph.degree(n)) for n in graph.nodes)
    edge_latency = sum(graph.edges[e].get("latency", 1.0) for e in graph.edges)
    return node_load + lambda_latency * edge_latency
```

Default assumptions:

- if `load` is missing, node degree is used as proxy load,
- if `latency` is missing, latency defaults to `1.0`,
- high-degree hubs have higher load,
- dense graphs may reduce path length but increase energy cost.

---

## 2.2 Hamiltonian vs Optimization Objective

The existing adaptive optimizer currently uses an objective similar to:

```text
objective =
    global_efficiency
  + path_score
  + clustering_score
  - density_penalty
  - component_penalty
```

This is a utility-like objective.

The Hamiltonian is a cost-like objective.

Relationship:

```text
maximize utility  ≈  minimize Hamiltonian
```

Recommended mapping:

$$
U[G] = -H[G] + \alpha \cdot \text{efficiency}(G) + \beta \cdot \text{clustering}(G)
$$

Where:

- $U[G]$ is the utility objective,
- $H[G]$ is the Hamiltonian cost,
- $\alpha$ rewards global efficiency,
- $\beta$ rewards useful local clustering.

---

# 3. Expansion Constant Λ

The **Expansion Constant** $\Lambda$ controls when dense structures become significant enough to trigger graph evolution.

In the current implementation this is represented by:

```python
clique_threshold
```

Example:

```python
kernel = QuantumHybridGraph(
    initial_nodes=10,
    clique_threshold=5,
    seed=42,
)
```

---

## 3.1 Meaning of Λ

| Parameter | Meaning |
|---|---|
| Low `clique_threshold` | More sensitive accelerator detection, faster expansion, more noise |
| High `clique_threshold` | Conservative accelerator detection, fewer false positives, slower expansion |

Conceptually:

$$
\Lambda = \text{minimum clique size required for accelerator activation}
$$

If a clique or dense accelerator exceeds $\Lambda$, the kernel may:

1. mark it as an accelerator,
2. use it as an optimization anchor,
3. trigger QAOA-style MaxClique search,
4. propose shortcut edges,
5. influence future graph expansion.

---

## 3.2 Expansion Rule

A simplified expansion rule:

```text
if size(accelerator) >= Λ:
    activate accelerator
    run QAOA-style optimization
    propose new shortcut edges
    update graph state
```

In code this is distributed across:

```python
detect_accelerators()
optimize_via_qaoa()
run_cycle()
```

---

# 4. Cost Edges J

Edges are interpreted as cost-bearing couplings.

In physics-inspired notation:

$$
J_{ij} = \text{coupling strength or cost between node } i \text{ and node } j
$$

In graph terms:

```python
graph.edges[i, j]["latency"]
graph.edges[i, j]["weight"]
graph.edges[i, j]["risk"]
```

Recommended edge schema:

```python
graph.add_edge(
    source,
    target,
    weight=1.0,
    latency=1.0,
    risk=0.0,
    relation="dependency",
)
```

---

## 4.1 Edge Cost Function

A generalized edge cost:

$$
C_{ij} = w_1 \cdot \text{latency}_{ij} + w_2 \cdot \text{risk}_{ij} + w_3 \cdot \text{maintenance}_{ij}
$$

Suggested implementation:

```python
def edge_cost(attrs, latency_weight=1.0, risk_weight=1.0, maintenance_weight=1.0):
    return (
        latency_weight * attrs.get("latency", 1.0)
        + risk_weight * attrs.get("risk", 0.0)
        + maintenance_weight * attrs.get("maintenance", 0.0)
    )
```

---

# 5. Accelerator Dynamics

Accelerators are dense or structurally important graph regions.

Detected by:

```python
GraphAcceleratorDetector
QuantumHybridGraph.detect_accelerators()
```

Supported accelerator types:

- cliques,
- k-core components,
- modularity communities,
- hub ego-networks,
- Grover-style clique candidates.

Each accelerator includes:

```python
Accelerator(
    id=...,
    nodes=...,
    kind=...,
    size=...,
    internal_edges=...,
    boundary_edges=...,
    density=...,
    conductance=...,
    average_degree=...,
    score=...,
)
```

---

## 5.1 Accelerator Score

The current accelerator score rewards:

- size,
- density,
- average internal degree,
- clique structure,
- k-core structure,
- hub ego structure.

It penalizes excessive conductance.

Conceptually:

$$
A(S) = |S| \cdot \rho(S) + \gamma \cdot \bar{d}(S) - \eta \cdot \phi(S)
$$

Where:

- $S$ is a subgraph,
- $\rho(S)$ is density,
- $\bar{d}(S)$ is average internal degree,
- $\phi(S)$ is conductance.

---

# 6. QAOA-style MaxClique Layer

The system includes a QAOA-inspired optimization layer for MaxClique.

Core class:

```python
QAOAOptimizer
```

Related components:

```python
QiskitAdapter
PennyLaneAdapter
CircuitDepthSelector
QuantumHybridGraph.optimize_via_qaoa()
```

---

## 6.1 MaxClique QUBO

The MaxClique problem is represented as:

$$
\min_x \left(-\sum_i x_i + P \sum_{(i,j) \notin E} x_i x_j\right)
$$

Where:

- $x_i \in \{0,1\}$ indicates whether node $i$ is selected,
- $P$ is a penalty for selecting non-connected node pairs,
- lower energy corresponds to larger valid cliques.

Implemented by:

```python
QAOAOptimizer.cost_energy(bitstring)
QuantumBackendAdapter.build_max_clique_qubo(graph)
```

---

## 6.2 Clique Purity

Clique purity is a validation metric:

$$
\text{purity}(S) = \frac{\text{existing internal edges in } S}{\text{all possible internal edges in } S}
$$

Implemented by:

```python
QAOAOptimizer.clique_purity(nodes_or_bitstring)
```

Interpretation:

| Purity | Meaning |
|---|---|
| `1.0` | Perfect clique |
| `0.7–0.99` | Near-clique / dense candidate |
| `< 0.7` | Weak clique candidate |

---

## 6.3 COBYLA Optimization

The QAOA angle optimizer uses multi-start COBYLA when SciPy is available.

```python
optimizer.optimize_cobyla(
    iterations=120,
    restarts=4,
)
```

Metadata is stored in:

```python
optimizer.last_optimizer_metadata
```

Includes:

- optimizer type,
- restarts,
- expected energy,
- bitstring,
- raw selected nodes,
- raw clique purity,
- projected clique,
- projected clique purity.

---

# 7. Adaptive Optimization Loop

The adaptive optimizer loop controls graph evolution.

Core class:

```python
AdaptiveGraphOptimizer
```

Attached API:

```python
kernel.adaptive_optimize(...)
```

---

## 7.1 Iteration Rule

Each iteration performs:

```text
G_t
→ analyze graph
→ detect accelerators
→ propose edge candidates
→ apply candidate
→ evaluate objective
→ accept or revert
→ G_{t+1}
```

Each step records:

```python
AdaptiveOptimizationStep(
    iteration=...,
    objective_before=...,
    objective_after=...,
    objective_delta=...,
    accepted=...,
    added_edges=...,
    reason=...,
)
```

This makes graph evolution auditable.

---

# 8. Reliability and Quarantine Layer

The reliability layer is handled by:

```python
NetworkReliabilityEngineer
AdaptiveNRE
```

It provides:

- health snapshots,
- risky node detection,
- quarantine behavior,
- sandbox analysis,
- incident history.

## 8.1 Network Reliability Engineer (NRE) Agent

`AdaptiveNRE` is the agent responsible for network stability and security.

**Adaptation Logic.** The agent maintains a `critical_energy_threshold` that is
dynamically adjusted from historical network-energy data. Per-node "energy" is
the degree normalized by the maximum degree; `observe_energy` records snapshots
(mean, std, p90) and `adapt_threshold` moves the threshold toward the historical
high-energy band with a configurable `adaptation_rate`, clamped to
`[min_threshold, max_threshold]`. This keeps the agent sensitive in quiet
networks and tolerant in naturally busy ones.

**Self-Healing.**

- *Quarantine.* `quarantine_node(node_id)` isolates nodes exhibiting anomalies
  (DoS/flood). `detect_energy_anomalies` flags nodes whose energy exceeds the
  adaptive threshold as `dos_flood_suspect`, and `auto_quarantine` isolates them
  automatically using that threshold.
- *Sandbox.* Infected nodes are moved into `self.sandbox` (an isolated
  `networkx.Graph`) together with their incident edge context, so threats can be
  analyzed via `analyze_sandbox` without interrupting the main network.
  `restore_node` returns a cleared node to the main graph.

**Recovery Procedures (self-healing back into production).** Returning a node is
evidence-based, not blind:

- `assess_recovery(node_id)` decides whether a quarantined node is safe to
  restore. A node is recoverable when it is no longer a high-degree outlier
  (`degree_z_score < 2.0` vs. the surviving degree distribution) **or** its
  projected energy is within the safe band (`critical_energy_threshold` minus a
  hysteresis margin to prevent flapping). A flood/DoS hub stays deferred.
- `recover_node(node_id, restore_edges=True, force=False)` re-attaches the node,
  reconnects only edges to *surviving* neighbours, cleans the sandbox, emits an
  `announce_route` policy and journals the event in `recovery_history`.
- `auto_recover(limit=None)` recovers every node that passes the assessment and
  leaves the rest deferred.
- `rollback_quarantine(node_id)` force-restores a confirmed false positive
  (recorded as `forced=True`).
- `recovery_report()` summarizes recovery readiness (`recoverable_now`,
  `deferred`) and the recovery audit trail.

The operational runbook (roles, failure scenarios, system-level restart and
state rebuild, verification checklist) lives in `docs/recovery_procedures.md`.

Key API:

```python
nre = AdaptiveNRE(kernel, critical_energy_threshold=0.75, adaptation_rate=0.25)
nre.adapt_threshold()             # update threshold from history
nre.detect_energy_anomalies()     # DoS/flood + structural incidents
nre.auto_quarantine(limit=2)      # self-healing isolation into sandbox
nre.analyze_sandbox()             # study trapped nodes
nre.reliability_report()          # full adaptive report
```

**Monitoring and auditing.**

- `export_incident_log(path, append=True)` persists a JSON audit trail
  containing the adaptive threshold state, energy history, detected anomalies,
  quarantine actions and current sandbox contents.
- `security_dashboard_payload()` shapes the same data for the dashboard, and
  `QuantumHybridGraph.export_dashboard_html(..., nre=nre)` renders a dedicated
  **Security** panel (adaptive threshold, anomalies, quarantine zone, sandbox).
  When per-cycle monitoring has run, the panel also charts the monitoring
  history: a threshold line over cycles plus incident and quarantine bars,
  sourced from `kernel.nre_incident_history`.

**Per-cycle monitoring.** The agent can be wired into the evolution loop so the
reliability layer runs automatically:

```python
kernel.enable_nre_monitoring(
    auto_quarantine=True,
    quarantine_limit=1,
    incident_log_path="cycle_incidents.json",
)
for _ in range(10):
    kernel.run_cycle()  # adapt threshold, log incidents, optional quarantine
```

Each cycle adapts the threshold, records a snapshot in
`kernel.nre_incident_history` (surfaced in `summary()`), optionally
auto-quarantines anomalous nodes and appends the JSON audit trail. Because
quarantine can remove nodes mid-loop, `expand_qpa` derives new node ids from the
maximum existing integer id, keeping graph growth consistent.

---

## 8.1 Sandbox Model

When a node is quarantined:

```python
nre.quarantine_node(node_id)
```

The node is removed from the main graph and copied into:

```python
nre.sandbox
```

The sandbox preserves:

- quarantined node,
- incident edges,
- neighbor context nodes,
- quarantine reason,
- quarantine history.

---

# 9. System Configuration Constants

Recommended deployment-level constants:

```python
config = {
    "clique_threshold": 4,
    "qaoa_layers": 2,
    "max_candidates": 1000,
    "add_edges_per_step": 1,
    "adaptive_iterations": 5,
    "density_penalty": 0.05,
    "quarantine_threshold": 0.75,
    "backend": "local_simulator",
}
```

---

## 9.1 Business-to-Physics Mapping

| Business requirement | NexusGraph parameter |
|---|---|
| Faster runtime | lower `max_candidates`, lower `top_n`, smaller QAOA subgraphs |
| Higher stability | higher `patience`, fixed `seed`, COBYLA optimizer |
| More innovation/exploration | lower `min_delta`, higher `max_iterations` |
| Lower risk | higher `quarantine_threshold` sensitivity, NRE monitoring |
| Lower graph densification | higher `density_penalty`, lower `add_edges_per_step` |
| More quantum differentiation | enable `qiskit` / `pennylane`, QUBO export |
| Executive clarity | dashboard export, summary reports |

---

# 10. Dashboard and Observability

Dashboard export:

```python
kernel.export_dashboard_html("quantum_hybrid_graph_dashboard.html")
```

The dashboard exposes:

- graph visualization,
- metrics,
- accelerators,
- connection candidates,
- a Security panel (when `nre=` is supplied) with the adaptive threshold,
  anomalies, quarantine zone and per-cycle monitoring chart,
- a Routing / Control Plane panel auditing the BGP/SDN command journal, with an
  offline BGP ⇄ SDN/OpenFlow view toggle,
- quantum backend status,
- embedded JSON.

Recommended future observability additions:

- Hamiltonian trajectory,
- entropy trajectory,
- objective delta chart,
- quarantine events,
- QAOA clique purity panel,
- edge cost heatmap.

---

# 11. Recommended Next Implementation

To fully align NexusGraph Dynamics with this manual, add:

```python
class GraphHamiltonian:
    def node_load(self, graph): ...
    def edge_latency(self, graph): ...
    def energy(self, graph): ...
    def free_energy(self, graph, temperature): ...
```

Then integrate it with:

- `AdaptiveGraphOptimizer`,
- `RealWorldBenchmarkSuite`,
- `export_dashboard_html`,
- `AdaptiveNRE`,
- investor/pilot reports.

---

# 11b. Checkpoint / Restore (state recovery)

Kernel state lives in memory. `checkpoint()` returns a JSON-serializable
snapshot of the full state; `save_checkpoint(path)` writes it to disk;
`restore(state)` rebuilds in place; and the `from_checkpoint(path_or_dict)`
classmethod constructs a kernel directly from a checkpoint.

```python
kernel.save_checkpoint("kernel_checkpoint.json")
# ... process restart ...
kernel = QuantumHybridGraph.from_checkpoint("kernel_checkpoint.json")
```

A checkpoint captures the graph (node-link form), the evolution clock and
`history`, the RNG state, kernel configuration, the accelerator/analysis/
connection/experiment histories, NRE monitoring flags and the attached
`AdaptiveNRE` agent (threshold, energy history, sandbox graph, quarantine and
recovery audit trails, BGP/SDN routing journal). Derived caches (rich report
objects, backend registry) are not persisted and are recomputed lazily.

Restore reproduces the graph, NRE state and RNG faithfully, so the next
deterministic operation is a continuation. Exact tie-breaking across many future
cycles is not guaranteed bit-identical after a re-serialized graph reload
(per-node adjacency order is not preserved by serialization); the recovered
state itself is faithful. See `docs/recovery_procedures.md` §5 and
`examples/checkpoint_restore_example.py`.

---

# 12. Minimal Example

```python
from quantum_hybrid_graph import QuantumHybridGraph

kernel = QuantumHybridGraph(
    initial_nodes=10,
    clique_threshold=4,
    qaoa_layers=2,
    seed=42,
)

for _ in range(5):
    kernel.run_cycle()

report = kernel.analyze_network()
result = kernel.adaptive_optimize(max_iterations=5)
kernel.export_dashboard_html("nexus_dashboard.html")

print(kernel.summary())
```

---

# 12b. Integration & Protocols

The kernel exposes an integration layer between graph intelligence and the
network control plane.

## BGP/SDN Interface

`BGPSDNInterface` maps graph operations onto routing-policy update commands.
Each operation produces a protocol-neutral `RoutingPolicyCommand` that can be
rendered as a BGP policy statement (`to_bgp`) or an SDN/OpenFlow flow rule
(`to_sdn`). Supported actions:

- `blackhole` / `withdraw_route` — isolate a quarantined node (security).
- `announce_route` — re-advertise a restored node.
- `install_path` — program an optimized clique/shortcut as a high-priority path.
- `set_local_pref` — re-weight a link to steer traffic.

The NRE emits these automatically on quarantine and restore, and all commands
are journaled for audit/replay by a downstream BGP speaker or SDN controller:

```python
nre = kernel.attach_reliability_engineer(critical_energy_threshold=0.85)
nre.adapt_threshold()
event = nre.auto_quarantine(limit=1, adapt=False)[0]
print(event["bgp"])  # blackhole policy for the isolated node

nre.routing.export_policy("routing_policy.txt", fmt="bgp")
nre.routing.export_policy("routing_policy.json", fmt="sdn")
```

The command journal is also surfaced in the HTML dashboard. Passing the NRE to
`export_dashboard_html(..., nre=nre)` embeds `nre.routing.as_dict()` and renders
a **Routing** tab: per-command cards (action, target, reason) colour-coded by
action, summary metrics (protocol, command count, blackhole/withdraw count,
path installs), and a BGP ⇄ SDN/OpenFlow view toggle that re-renders the
journal entirely offline. See `examples/routing_control_plane_dashboard_example.py`.

## Quantum Backend

The Qiskit / PennyLane (or local) backends solve `MaxClique` for global
optimization. `optimize_routes_via_qaoa` connects that result to the control
plane: the densest cluster (clique) is programmed as a high-priority routing
path, steering traffic through the optimal low-latency core.

```python
result = kernel.optimize_routes_via_qaoa(backend="local", iterations=30)
print(result["clique"])  # optimal routing core
print(result["bgp"])     # install path [...]
print(result["sdn"])     # {'action': 'FORWARD', 'priority': 300, ...}
```

---

# 13. Conceptual Summary

NexusGraph Dynamics treats a graph as a living optimization system.

- Nodes carry load.
- Edges carry latency and cost.
- Dense structures become accelerators.
- QAOA identifies high-value clique structures.
- Adaptive optimization adds only justified connections.
- Reliability engineering quarantines risky nodes.
- The dashboard exposes the state of the network universe.

The goal is not uncontrolled growth.

The goal is:

```text
controlled evolution of graph intelligence
```
